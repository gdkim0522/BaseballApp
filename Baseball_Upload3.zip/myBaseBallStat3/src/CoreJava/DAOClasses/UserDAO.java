package CoreJava.DAOClasses;

import java.sql.SQLException;


import CoreJava.Models.User;
import CoreJava.SystemInterfaces.UserDAOI;


/**
 * 
 * @author Greg Kim
 *
<div>
Access User Log In Information
</div>
 */
public class UserDAO extends AbstractDAO implements UserDAOI{

	String NEW_LINE= "\n";
	String CD= ",";
	String ExceptionMSG="EX MESSAGE: ";
	String SQLExceptionMSG="SQL EXCEPT: ";
	String method="UserDAO - ";
	
	public UserDAO() {
		// TODO Auto-generated constructor stub
	}
	


	@Override
	public int addUser(String first_name, String last_name, String user_name, String password)
			throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		method="UserDAO - ";
		method=method.concat("addUser() - ");				
		int result=0;
		
		try
		{ 
			connect();
			
			ps=conn.prepareStatement(SQL.ADD_USER.getQuery());

  			//Run Insert
  			ps.setString(1, first_name);
  			ps.setString(2, last_name);
  			ps.setString(3, user_name);
  			ps.setString(4, password);
  			
  			result= ps.executeUpdate();
  			if(result==1)
  				return 1;
  			else
  				return -100;
        } catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(method +EXSQL + e.getMessage());
		}catch(Exception ex) { 
			System.out.println(method +EX + ex.getMessage()); 
		}finally {
         dispose();
      } 
		
		return -100;
	}

	@Override
	public User validateUser(String user_name, String password)
			throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		User user=null;
		
		try
		{ 
			this.connect();
						
			ps=conn.prepareStatement(SQL.GET_USER.getQuery());
  			ps.setString(1, user_name);
  			ps.setString(2, password);
			rs=ps.executeQuery();  
					  
			if(rs.next()) {
				user=new User();
				
				user.setFirstName(rs.getString(2));
				user.setLastName(rs.getString(3));
				user.setUserName(rs.getString(4));
				user.setPassword(rs.getString(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(EXSQL + e.getMessage());
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println(EX + e.getMessage());
		}finally {
			dispose();
		}
		
		return user;
	}



	@Override
	public int deleteUser(String user_name) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		method="UserDAO - ";
		method=method.concat("deleteUser() - ");				
		int result=0;
		
		try
		{ 
			connect();
			
			ps=conn.prepareStatement(SQL.DELETE_USER.getQuery());

  			ps.setString(1, user_name);
  			
  			result= ps.executeUpdate();
  			
  			//System.out.println("DELETE COMMAND: " + result);
  			
  			if(result==1)
  				return 1;
  			else
  				return -100;
        } catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(method +EXSQL + e.getMessage());
		}catch(Exception ex) { 
			System.out.println(method +EX + ex.getMessage()); 
		}finally {
         dispose();
      } 
		
		return -100;
	}

}
