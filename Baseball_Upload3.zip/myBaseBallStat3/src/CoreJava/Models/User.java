package CoreJava.Models;

import org.hibernate.validator.constraints.NotEmpty;

import com.mybaseball.customAnnotations.PassConstraint;


/**
 * 
 * This is the User class which holds all the relevant data for each user. 
 * 
 * @author Greg Kim
 *
 */


public class User {
	
	@NotEmpty(message = "FirstName may not be empty")	
	private String firstName;
	
	@NotEmpty(message = "LastName may not be empty")
	private String lastName;
	
	@NotEmpty(message = "UserName may not be empty")
	private String userName;
	private String gender;
	
	@PassConstraint
	private String password;

	
	public User() {
		// TODO Auto-generated constructor stub
	}
	
	public boolean equals(Object object) {
		if(object instanceof User) {
			User other=(User) object;
			boolean SameFirstName=this.firstName.equals(other.getFirstName());
			boolean SameLastName=this.lastName.equals(other.getLastName());
			boolean SameUserName=this.userName.equals(other.getUserName());
			boolean SamePassword=this.password.equals(other.getPassword());
			
			if(SameFirstName && SameLastName && SameUserName && SamePassword)
				return true;
			else
				return false;
		}else
			return false;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
