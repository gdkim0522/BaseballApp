package CoreJava.Models;


/**
 * 
 * This is the Hitter class which holds all the relevant data for each hitter. 
 * 
 * @author Greg Kim
 *
 */


public class Hitter extends Player {

	public Hitter(int player_id, int team_id, String fullName, int at_bats, int runs, int hits, int doubles,
			int homeruns,int rbi, int walks, int strikeouts) {
		super(player_id, team_id, fullName, at_bats, runs, hits, doubles, homeruns,rbi, 
				walks, strikeouts);
		// TODO Auto-generated constructor stub
	}

	public Hitter() {
		// TODO Auto-generated constructor stub
	}


	
}
