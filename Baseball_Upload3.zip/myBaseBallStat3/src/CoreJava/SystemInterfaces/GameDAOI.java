package CoreJava.SystemInterfaces;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import CoreJava.Models.GameLog;


public interface GameDAOI {
	
	public enum SQL{
		ADD_GAMELOG("INSERT INTO gamelog(play_series,current_Play, current_result,inning,is_top,balls,strikes,outs,visit_runs,home_runs"
				+ ",hitter_id,pitcher_id,score_Updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)"),
		GET_GAMELOG_SCORE("select * from gamelog where score_updated=? order by play_series"),
		GET_GAMELOG_CURRENT("select * from gamelog where hitter_id=? and play_series>? order by play_series"),
		GET_GAMELOG_CURRENTHITTER("select * from gamelog where hitter_id=? order by play_series"),
		TRUNCATE_TABLE_GAMELOG("Truncate table gamelog");
		
		private final String query;
		
		private SQL(String query) {
			this.query=query;			
		}
		
		public String getQuery() {
			return this.query;
		}
		
	}
	
	int addGameLog(int playlog,int current_play, String result, int inning, boolean top, int balls, int strikes,
			int outs, int visit_runs, int home_runs, int hitter_id, int pitcher_id, boolean score_updated) throws ClassNotFoundException, SQLException;
	
	List<GameLog> getGameLogScore(String scoreupdated) throws ClassNotFoundException, IOException,SQLException;

	List<GameLog> getGameLogCurrent(int hitter_id, int play_series) throws ClassNotFoundException, IOException,SQLException;
	
	List<GameLog> getGameLogCurrentHitter(int hitter_id) throws ClassNotFoundException, IOException,SQLException;
	
	int truncateGameLog()  throws ClassNotFoundException, IOException,SQLException;
}
