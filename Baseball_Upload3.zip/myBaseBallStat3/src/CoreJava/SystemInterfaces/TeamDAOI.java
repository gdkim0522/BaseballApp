package CoreJava.SystemInterfaces;

import java.sql.SQLException;
import java.util.List;

import CoreJava.Models.Team;

public interface TeamDAOI {
	enum SQL{
		GET_TEAM_BY_ID("Select * from team where team_id=?"),
		GET_ALL_TEAMS("Select * from team"),
		GET_TEAM_STANDINGS("select * from team order by wins desc"),
		UPDATE_TEAM_WINS("update team set wins=wins+1 where team_id=?"),
		UPDATE_TEAM_LOSSES("update team set losses=losses+1 where team_id=?");
		
		
		
		private final String query;
		
		private SQL(String s) {
			this.query=s;
		}
		
		public String getQuery() {
			return this.query;
		}
	}
	
	public Team getTeamById(int team_id) throws SQLException, ClassNotFoundException;
	
	public List<Team> getAllTeams() throws SQLException, ClassNotFoundException;
	
	public List<Team> getTeamStandings() throws SQLException, ClassNotFoundException;
	
	public int updateTeamWins(int team_id) throws SQLException, ClassNotFoundException;
	
	public int updateTeamLosses(int team_id) throws SQLException, ClassNotFoundException;
	
}
