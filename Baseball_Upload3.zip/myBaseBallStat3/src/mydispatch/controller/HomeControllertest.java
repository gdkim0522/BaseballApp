//package mydispatch.controller;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;
//
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.servlet.ModelAndView;
//import CoreJava.DAOClasses.HitterDAO;
//import CoreJava.Models.Course;
//import CoreJava.Models.Game;
//import CoreJava.Models.Pitcher;
//
//import com.assign9.*;
///**
// * 
// * @author Greg Kim
// * 
// * Home Controller
// *
// */
//
//@Controller
//public class HomeControllertest {
//		
//		@RequestMapping("/")
//		public ModelAndView indexPage() {
//			System.out.println("This is index");
//			
//			ModelAndView mav=new ModelAndView("index");
//			
//			//Employee employee=new Employee();
//			
////			String visit_id=pRequest.getParameter("visit_team");
////			String home_id=pRequest.getParameter("home_team");
////			
////			int visitid=Integer.parseInt(visit_id);
////			int homeid=Integer.parseInt(home_id);
//		
//			
//			//Course course=new Course();
//			
//			//Game ballgame=new Game();
////			ballgame.assignHittersDAO(visitid, homeid, 1 ,3);
////			Pitcher home_pitcher=ballgame.getCurrent_HomePitcher();
////			Pitcher visit_pitcher=ballgame.getCurrent_VisitPitcher();
////			
////			
////			mav.addObject("visit_pitcher", visit_pitcher);
////			mav.addObject("home_pitcher", home_pitcher);
//////			
//////			System.out.println("This is going throught");
////			System.out.format("v_id is %s and h_id is %s. %n", visit_id,home_id);
////			
//			return mav;
//		}
//		
//		@RequestMapping("/selectionpage")
//		public ModelAndView selectindexPage() {
//			System.out.println("This is index");
//			
//			ModelAndView mav=new ModelAndView("selectionpage");
//			
//			//Employee employee=new Employee();
//			
////			String visit_id=pRequest.getParameter("visit_team");
////			String home_id=pRequest.getParameter("home_team");
////			
////			int visitid=Integer.parseInt(visit_id);
////			int homeid=Integer.parseInt(home_id);
//		
//			
//			//Course course=new Course();
//			
//			//Game ballgame=new Game();
////			ballgame.assignHittersDAO(visitid, homeid, 1 ,3);
////			Pitcher home_pitcher=ballgame.getCurrent_HomePitcher();
////			Pitcher visit_pitcher=ballgame.getCurrent_VisitPitcher();
////			
////			
////			mav.addObject("visit_pitcher", visit_pitcher);
////			mav.addObject("home_pitcher", home_pitcher);
//////			
//////			System.out.println("This is going throught");
////			System.out.format("v_id is %s and h_id is %s. %n", visit_id,home_id);
////			
//			return mav;
//		}
//		
////		@RequestMapping(value= {"/selectionpage"},method=RequestMethod.POST)
////		public ModelAndView getPlayers(HttpServletRequest pRequest){
////			
//////			System.out.println("This is post");
//////			ModelAndView mav=new ModelAndView("index");
//////			
//////			String visit_id=pRequest.getParameter("visit_team");
//////			String home_id=pRequest.getParameter("home_team");
//////			
//////			int visitid=Integer.parseInt(visit_id);
//////			int homeid=Integer.parseInt(home_id);
//////			
//////			System.out.format("v_id is %s and h_id is %s. %n", visit_id,home_id);
////////			
//////			//Game ballgame=new Game();
//////			//ballgame.assignHittersDAO(visitid, homeid, 1 ,3);
////////			Pitcher home_pitcher=ballgame.getCurrent_HomePitcher();
////////			Pitcher visit_pitcher=ballgame.getCurrent_VisitPitcher();
////////
////////			System.out.format("Name is %s", home_pitcher.getFullname());
//////			
////////			mav.addObject("visit_pitcher", visit_pitcher);
////////			mav.addObject("home_pitcher", home_pitcher);
//////			
////////			ModelMap modelMap=new ModelMap();
////////			modelMap.put("visit_pitcher", visit_pitcher);
////////			modelMap.put("home_pitcher", home_pitcher);
//////			
//////			return mav;
////		}
//		
//		@RequestMapping("/Baseball_Tracker")
//		public ModelAndView firstPage() {
//			ModelAndView mav=new ModelAndView("Baseball_Tracker");
//			
//			return mav;
//		}
//		
//		@RequestMapping(value= {"/selectionpage"},method=RequestMethod.POST)
//		public ModelAndView selectionPage(HttpServletRequest pRequest) {
//			ModelAndView mav=new ModelAndView("selectionpage");
//			
//			String visit_id=pRequest.getParameter("visit_team");
//			String home_id=pRequest.getParameter("home_team");
//			
//			int visitid=Integer.parseInt(visit_id);
//			int homeid=Integer.parseInt(home_id);
////		
////			
////			//Course course=new Course();
////			
//			try {
//				Game ballgame=new Game();
//				
//
//				//ballgame.assignHittersDAO(visitid, homeid, 1 ,3);
//				//ballGame.assignHittersDAO(1, 2, 1, 3);
//				ballgame.assignHittersDAO(1, 2, 1, 3);
//				Pitcher home_pitcher=ballgame.getCurrent_HomePitcher();
//				Pitcher visit_pitcher=ballgame.getCurrent_VisitPitcher();
//
//			} catch (Exception e) {
//				System.out.println(e.getMessage());
//			}
//
//			
//			return mav;
//		}
//		
//		@RequestMapping("/index")
//		public ModelAndView thirdPage() {
//			ModelAndView mav=new ModelAndView("index");
//			
//			return mav;
//		}
//		
//		@RequestMapping("/logout")
//		public ModelAndView indexPage_1() {
//			ModelAndView mav=new ModelAndView("logout");
//			
//			return mav;
//		}
//}
