package mydispatch.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import CoreJava.Models.Game;
import CoreJava.Models.Hitter;
import CoreJava.Models.Pitcher;

@Controller

public class TestController {
	String base_situation;

	/**
	 * Handler to gather user input
	 * @param pRequest
	 * @param result
	 * @param move_to
	 * @return
	 */
	
	
	@RequestMapping(value= {"/test"},method=RequestMethod.POST)
	public ModelAndView inputPost(HttpServletRequest pRequest, HttpServletResponse pResponse,
			@RequestParam("inputId") String result, @RequestParam("runnerId") String move_to) {
		
		try {
			

			HttpSession session=pRequest.getSession();
			Game ballgame=(Game) session.getAttribute("ballgame");
						
			ModelAndView mav=new ModelAndView("tracker");
			
			int v_result=Integer.parseInt(result);
			int v_move_to=Integer.parseInt(move_to);

			
			System.out.println("Test Result: " + v_result);		
			System.out.println("Move_to: " + v_move_to);	
			
			Hitter current_hitter=ballgame.getCurrent_Hitter();
			Pitcher current_pitcher=ballgame.getCurrent_Pitcher();
			
			Map<Integer, Hitter> OnBase=ballgame.getOnBase();
																		


			
			if(v_result>=1 && v_result<=9) {
				//Ask for advance runner input
				if(ballgame.isRunnersOnBase() && v_result>=1 && v_result<=3) {
					if (v_result>=1 && v_result<=3) {
				
						//Show runner menu
						for(int i=3;i>0;i--) {
							ballgame.getBaseSituations(v_result, i);
							base_situation=ballgame.getCurrent_base_situation();
							
							if(base_situation.length()>3) {
								mav.addObject("Base", i);
								mav.addObject("MoveRunner",1);
								mav.addObject("Runner_situation",base_situation);
								mav.addObject("current_result", ballgame.getCurrent_result());
								session.setAttribute("current_base", i);
								session.setAttribute("current_input", v_result);
								break;
							}
						}
					
					}
				}
					
//					
//					for(int i=3;i>=0;i--) {
//						if(OnBase.get(i)!=null && OnBase.get(i-1)!=null && OnBase.get(i-2)!=null && i==3) {
//							Hitter runner=OnBase.get(i);
//							ballgame.setBaseSituation(i, current_hitter);
//							//System.out.print(runner.getFullName() + " is on " + i + ". ");
//						}
//					}
					
					
					
//					if(RunnersOnBase) {
//						//setBaseSituations(scanner);
//					}
//					
//					
//					if(RunnersOnBase) {
//						//setBaseSituations(scanner);
//					}
//					
//					//If player walks, put him on base
//					//OnBase.put(1, current_Hitter);
//					//setBaseSituation(1, current_Hitter);
//					//If player walks, put him on base
//					OnBase.put(1, current_hitter);
//					ballgame.setBaseSituation(1, current_hitter);
//					
//					ballgame.recordTransaction(v_result);
//					ballgame.updateTransaction();
//					mav.addObject("current_result", ballgame.getCurrent_result());
//					mav.addObject("MoveRunner",0);
//					
//					Hitter runner=ballgame.getCurrent_Hitter();
//					bal
//					
//					
//					ballgame.advanceRunner(frombase, tobase);
					
					
				else{
					//Show regular menu

					ballgame.recordTransaction(v_result);
					ballgame.updateTransaction();
					mav.addObject("current_result", ballgame.getCurrent_result());
					mav.addObject("MoveRunner",0);
					
				}
			}
				
			

			
			if(ballgame.checkifGameOver()) {
				mav=new ModelAndView("results");
				
				mav.addObject("visit_team_hitters", ballgame.getVisit_Hitters());
				mav.addObject("home_team_hitters", ballgame.getHome_Hitters());	
				mav.addObject("visit_team", ballgame.getVisit_team());
				mav.addObject("home_team", ballgame.getHome_team());
				mav.addObject("visit_runs", ballgame.getTotal_visitteam_runs());
				mav.addObject("home_runs", ballgame.getTotal_hometeam_runs());
				
				System.out.println("Game is over");
				
				return mav;
				//pResponse.sendRedirect("result");

			}
				
			
			ballgame.getGameMenu();			
			
																		
			for(int i=1;i<=OnBase.size();i++) {
				if(OnBase.get(i)!=null) {
					Hitter runner=OnBase.get(i);
					mav.addObject("Runner_" + i, runner.getFullName());
					//System.out.print(runner.getFullName() + " is on " + i + ". ");
				}
			}
			

			
			mav.addObject("visit_team", ballgame.getVisit_team());
			mav.addObject("home_team", ballgame.getHome_team());
									
			mav.addObject("current_hitter", ballgame.getCurrent_Hitter());
			mav.addObject("current_pitcher", ballgame.getCurrent_Pitcher());
			mav.addObject("balls", ballgame.getBalls());
			mav.addObject("strikes", ballgame.getStrikes());
			mav.addObject("outs", ballgame.getOuts());
			mav.addObject("inning", ballgame.getInning());
			mav.addObject("top", (ballgame.isTop())?"Top":"Bottom");	
			mav.addObject("visit_runs", ballgame.getTotal_visitteam_runs());
			mav.addObject("home_runs", ballgame.getTotal_hometeam_runs());
			
			//Set Session Attribute
			session.setAttribute("ballgame", ballgame);
			
				
			return mav;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Error: " + e.getMessage());
		}
		return null;
	}
	
	/**
	 * Handler to gather user input to advance runner
	 * @param pRequest
	 * @param move_to
	 * @param baseId
	 * @return
	 */
	
	
	@RequestMapping(value= {"/test-move_runner"},method=RequestMethod.POST)
	public ModelAndView movePost(HttpServletRequest pRequest, HttpServletResponse pResponse,
			@RequestParam("inputId") String move_to, @RequestParam("baseId") String baseId) {
		
		try {

			
			HttpSession session=pRequest.getSession();
			ModelAndView mav=new ModelAndView("tracker");
			
			
			Game ballgame=(Game) session.getAttribute("ballgame");
			int current_input=(int) session.getAttribute("current_input");
			
			//int base_count=(int) session.getAttribute("bases");
			//Map<Integer, Hitter> OnBase=ballgame.getOnBase();
			//OnBase.get(base_count);
			
			
			int v_move=Integer.parseInt(move_to);
			int v_base=Integer.parseInt(baseId);		
			
			
			//String move_result="Player 1 moved from " + baseId + " to " + move_to;

			ballgame.advanceRunner(v_base, v_move);

			//Look for next base
			v_base--;
			
			//mav.addObject("Result", move_result);
			mav.addObject("Base", v_base);
			
			
			
			//If bases are clear from input
			if(v_base==0) {

				ballgame.recordTransaction(current_input);
				ballgame.updateTransaction();
				mav.addObject("current_result", ballgame.getCurrent_result());
				mav.addObject("MoveRunner",0);
				
				ballgame.getGameMenu();			
				
				Hitter current_hitter=ballgame.getCurrent_Hitter();
				Pitcher current_pitcher=ballgame.getCurrent_Pitcher();
				
				mav.addObject("current_hitter", current_hitter);
				mav.addObject("current_pitcher", current_pitcher);
				
				if(ballgame.checkifGameOver()) {
					mav=new ModelAndView("results");
					
					mav.addObject("visit_team_hitters", ballgame.getVisit_Hitters());
					mav.addObject("home_team_hitters", ballgame.getHome_Hitters());	
					mav.addObject("visit_team", ballgame.getVisit_team());
					mav.addObject("home_team", ballgame.getHome_team());
					mav.addObject("visit_runs", ballgame.getTotal_visitteam_runs());
					mav.addObject("home_runs", ballgame.getTotal_hometeam_runs());
					
					System.out.println("Game is over");
					
					return mav;
				}
					
					
			}else {
				for(int i=v_base;i>0;i--) {
					ballgame.getBaseSituations(current_input, i);
					base_situation=ballgame.getCurrent_base_situation();
					
					if(base_situation.length()>3) {
						mav.addObject("Base", i);
						mav.addObject("MoveRunner",1);
						mav.addObject("Runner_situation",base_situation);
						session.setAttribute("current_base", i);
						session.setAttribute("current_input", current_input);
						break;
					}
				}
			}
			
			
			ballgame.getGameMenu();			
			
			Hitter current_hitter=ballgame.getCurrent_Hitter();
			Pitcher current_pitcher=ballgame.getCurrent_Pitcher();
			
			
			Map<Integer, Hitter> OnBase=ballgame.getOnBase();
			
			for(int i=1;i<=OnBase.size();i++) {
				if(OnBase.get(i)!=null) {
					Hitter runner=OnBase.get(i);
					mav.addObject("Runner_" + i, runner.getFullName());
					//System.out.print(runner.getFullName() + " is on " + i + ". ");
				}
			}
			
			mav.addObject("current_hitter", current_hitter);
			mav.addObject("current_pitcher", current_pitcher);
			mav.addObject("balls", ballgame.getBalls());
			mav.addObject("strikes", ballgame.getStrikes());
			mav.addObject("outs", ballgame.getOuts());
			mav.addObject("inning", ballgame.getInning());
			mav.addObject("top", (ballgame.isTop())?"Top":"Bottom");	
			mav.addObject("visit_runs", ballgame.getTotal_visitteam_runs());
			mav.addObject("home_runs", ballgame.getTotal_hometeam_runs());
			
			
			//Set Session Attribute
			session.setAttribute("ballgame", ballgame);
			
			return mav;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Error: " + e.getMessage());
		}
		return null;
	}
	
	
	/**
	 * Final page to render results
	 * @param pRequest
	 * @return
	 */
	
	
	
	@RequestMapping("/test_results")
	public ModelAndView resultPage(HttpServletRequest pRequest) {
		
		
		HttpSession session=pRequest.getSession();
		
		Game ballgame=(Game) session.getAttribute("ballgame");
		
		ballgame.getScoringSummary();
		
		ModelAndView mav=new ModelAndView("results");
		
		mav.addObject("visit_team_hitters", ballgame.getVisit_Hitters());
		mav.addObject("home_team_hitters", ballgame.getHome_Hitters());	
		mav.addObject("visit_team", ballgame.getVisit_team());
		mav.addObject("home_team", ballgame.getHome_team());
		mav.addObject("visit_runs", ballgame.getTotal_visitteam_runs());
		mav.addObject("home_runs", ballgame.getTotal_hometeam_runs());
		mav.addObject("scoring_summary", ballgame.getGamelog_Scoring());
		
		//Set Session Attribute
		session.setAttribute("ballgame", ballgame);
		

		
		return mav;
		
	}
}
