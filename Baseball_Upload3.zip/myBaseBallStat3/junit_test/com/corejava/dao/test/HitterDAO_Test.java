package com.corejava.dao.test;

import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.SQLException;

import java.util.LinkedList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import CoreJava.DAOClasses.HitterDAO;
import CoreJava.Models.Hitter;

public class HitterDAO_Test {

	Hitter hitterExpected;	Hitter hitterActual;
	HitterDAO hitterDAOExpected;	HitterDAO hitterDAOActual;	

	List<Hitter> lst_Hitters_Expected;	List<Hitter> lst_Hitters_Actual;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public final void testGetAllHittersByTeamID() {
		System.out.println("======== GET_ALL_HITTERS========");
		
		lst_Hitters_Expected=new LinkedList<Hitter>();
		lst_Hitters_Expected.add(new Hitter(1,1,"T. Jankowski",347,45,60,12,4,17,37,73));
		lst_Hitters_Expected.add(new Hitter(2,1,"E. Hosmer",613,72,155,31,18,69,62,142));
		lst_Hitters_Expected.add(new Hitter(3,1,"C. Villanueva",351,42,83,15,20,46,23,104));
		lst_Hitters_Expected.add(new Hitter(4,1,"F. Cordero",139,19,33,5,7,19,14,55));
		lst_Hitters_Expected.add(new Hitter(5,1,"R. Lopez",102,11,18,2,3,13,13,43));
		lst_Hitters_Expected.add(new Hitter(6,1,"J. Pirela",438,54,109,23,5,32,30,89));		
		
		try {
			hitterDAOActual=new HitterDAO();
			lst_Hitters_Actual=hitterDAOActual.getAllHittersByTeamID(1);
			
			assertEquals(6, lst_Hitters_Actual.size());
			
			System.out.println("LIST_EXPECTED == LIST_ACTUAL");
			assertEquals(lst_Hitters_Expected, lst_Hitters_Actual);
			
			for(int i=0;i<lst_Hitters_Expected.size();i++) {
				hitterExpected=lst_Hitters_Expected.get(i);
				hitterActual=lst_Hitters_Actual.get(i);
				
				System.out.println("COMPARE OBJECTS");
				assertEquals(hitterExpected, hitterActual);
			}
			
			
		}catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Class EX: " +e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("SQL EX: "+e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("IO  EX: "+e.getMessage());
		}
		//fail("Not yet implemented"); // TODO
	}
}
