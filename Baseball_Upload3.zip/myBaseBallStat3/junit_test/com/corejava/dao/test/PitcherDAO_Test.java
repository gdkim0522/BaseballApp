package com.corejava.dao.test;

import static org.junit.Assert.*;

import java.util.LinkedList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import CoreJava.DAOClasses.PitcherDAO;
import CoreJava.Models.Pitcher;
import java.io.IOException;
import java.sql.SQLException;


public class PitcherDAO_Test {
	Pitcher pitcherExpected;	Pitcher pitcherActual;
	PitcherDAO pitcherDAOExpected;	PitcherDAO pitcherDAOActual;	
	List<Pitcher> lst_Pitchers_Expected;	List<Pitcher> lst_Pitchers_Actual;
	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testGetPitcherByID() {
		System.out.println("======== GET_PITCHER_BY_ID========");
		
		pitcherExpected=new Pitcher(2,1,"B. Hand",2,4,44,33,15,15,65);	
		
		try {
			pitcherDAOActual=new PitcherDAO();
			pitcherActual=pitcherDAOActual.getPitcherByID(1, 2);

			System.out.println("COMPARE OBJECTS");
			assertEquals(pitcherExpected, pitcherActual);
		}catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Class EX: " +e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("SQL EX: "+e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("IO  EX: "+e.getMessage());
		}
		//fail("Not yet implemented"); 
		// TODO
	}

	@Test
	public final void testGetPitcherByTeamID() {
		System.out.println("======== GET_ALL_PITCHERS========");
		
		lst_Pitchers_Expected=new LinkedList<Pitcher>();
		lst_Pitchers_Expected.add(new Pitcher(1,1,"C. Richard",7,11,158,159,94,60,108));
		lst_Pitchers_Expected.add(new Pitcher(2,1,"B. Hand",2,4,44,33,15,15,65));
		
		try {
			pitcherDAOActual=new PitcherDAO();
			lst_Pitchers_Actual=pitcherDAOActual.getPitcherByTeamID(1);
			
			assertEquals(2, lst_Pitchers_Actual.size());
			
			System.out.println("LIST_EXPECTED == LIST_ACTUAL");
			assertEquals(lst_Pitchers_Expected, lst_Pitchers_Actual);
			
			
			for(int i=0;i<lst_Pitchers_Expected.size();i++) {
				
				pitcherExpected=lst_Pitchers_Expected.get(i);
				pitcherActual=lst_Pitchers_Actual.get(i);
				
//				hitterExpected=lst_Hitters_Expected.get(i);
//				hitterActual=lst_Hitters_Actual.get(i);
				
				System.out.println("COMPARE OBJECTS");
				assertEquals(pitcherExpected, pitcherActual);
			}
			
			
		}catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Class EX: " +e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("SQL EX: "+e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("IO  EX: "+e.getMessage());
		}
	}

}
