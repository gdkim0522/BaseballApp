package com.corejava.models.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import CoreJava.Models.Pitcher;

public class Pitcher_Test {
	Pitcher pitcher_expected;	Pitcher pitcher_actual;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("@BeforeClass - PITCHER MODEL");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("@AfterClass - PITCHER MODEL");
	}

	@Before
	public void setUp() throws Exception {
		
		pitcher_expected=new Pitcher(2,1,"B. Hand",2,4,44,33,15,15,65);
		pitcher_actual=new Pitcher();
		
		System.out.println("@Before TestSetters INTIZALIZE OBJECTS && TEST SETTERS");
		
		pitcher_actual.setPitcher_id(2);
		pitcher_actual.setTeam_id(1);
		pitcher_actual.setFullname("B. Hand");
		pitcher_actual.setWins(2);
		pitcher_actual.setLosses(4);
		pitcher_actual.setInnings(44);
		pitcher_actual.setHits(33);
		pitcher_actual.setRuns(15);
		pitcher_actual.setWalks(15);
		pitcher_actual.setStrikeouts(65);
		
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("@After FINISH METHOD");
	}

	@Test
	public final void testGetFullName() {
		System.out.println("@Test TestGetters TEST GETTERS");

		assertTrue(pitcher_expected.getPitcher_id()==pitcher_actual.getPitcher_id());
		assertTrue(pitcher_expected.getTeam_id()==pitcher_actual.getTeam_id());
		assertTrue(pitcher_expected.getFullname().equals(pitcher_actual.getFullname()));
		assertTrue(pitcher_expected.getWins()==pitcher_actual.getWins());
		assertTrue(pitcher_expected.getLosses()==pitcher_actual.getLosses());
		assertTrue(pitcher_expected.getInnings()==pitcher_actual.getInnings());
		assertTrue(pitcher_expected.getRuns()==pitcher_actual.getRuns());
		assertTrue(pitcher_expected.getHits()==pitcher_actual.getHits());
		assertTrue(pitcher_expected.getWalks()==pitcher_actual.getWalks());
		assertTrue(pitcher_expected.getStrikeouts()==pitcher_actual.getStrikeouts());
	}

	@Test
	public final void testSetFullName() {
		System.out.println("@Test EqualsObjects TEST OBJECTS ARE EQUAL");
		
		assertEquals(pitcher_expected, pitcher_actual);
	}

}
