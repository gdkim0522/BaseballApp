package com.corejava.models.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ Hitter_Test.class, Pitcher_Test.class, Team_Test.class,GameLog_Test.class,User_Test.class })
public class AllTests {

}
