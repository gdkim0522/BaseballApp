package com.corejava.models.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import CoreJava.Models.User;

public class User_Test {
	User user_expected;	User user_actual;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("@BeforeClass - USER MODEL");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("@AfterClass - USER MODEL");
	}

	@Before
	public void setUp() throws Exception {

		user_expected=new User();
		user_actual=new User();
		
		System.out.println("@Before TestSetters INTIZALIZE OBJECTS && TEST SETTERS");
		
		
		user_expected.setFirstName("First");
		user_expected.setLastName("last");
		user_expected.setUserName("uname");
		user_expected.setPassword("Pass");
		
		user_actual.setFirstName("First");
		user_actual.setLastName("last");
		user_actual.setUserName("uname");
		user_actual.setPassword("Pass");
	}
	

	@After
	public void tearDown() throws Exception {
		System.out.println("@After FINISH METHOD");
	}

	@Test
	public final void testGetFullName() {
		System.out.println("@Test TestGetters TEST GETTERS");

		assertTrue(user_expected.getFirstName().equals(user_actual.getFirstName()));
		assertTrue(user_expected.getLastName().equals(user_actual.getLastName()));
		assertTrue(user_expected.getUserName().equals(user_actual.getUserName()));
		assertTrue(user_expected.getPassword().equals(user_actual.getPassword()));
	}

	@Test
	public final void testSetFullName() {
		System.out.println("@Test EqualsObjects TEST OBJECTS ARE EQUAL");
		
		assertEquals(user_expected, user_actual);
	}

}
