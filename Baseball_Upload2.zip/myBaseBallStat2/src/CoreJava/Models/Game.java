package CoreJava.Models;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.taglibs.standard.lang.jstl.test.beans.PublicInterface2;

import CoreJava.DAOClasses.FileReaderCode;
import CoreJava.DAOClasses.GameDAO;
import CoreJava.DAOClasses.HitterDAO;
import CoreJava.DAOClasses.PitcherDAO;
import CoreJava.DAOClasses.TeamDAO;


// TODO: Auto-generated Javadoc
/**
 * 
 * This is the main class that will be instantiated and will be used throughout the program.   
 * This class will be used to keep track of the game and has methods that will be called based on the user input.  
 * It can also be used to determine the outcome of the game.  
 * The class will be instantiated once and passed along the Spring MVC web application as a Session object.
 * 
 * @author Greg Kim
 *
 */


public class Game {
	
	/** The top. */
	//Status of each transaction
	boolean top;
	
	/** The Runners on base. */
	boolean RunnersOnBase;
	
	/** The is walk. */
	boolean isWalk;
	
	/** The score updated. */
	boolean scoreUpdated;
	
	/** The inning. */
	int inning;
	
	/** The balls. */
	int balls;
	
	/** The strikes. */
	int strikes;
	
	/** The outs. */
	int outs;
	
	/** The visit runs. */
	int[] visit_runs;
	
	/** The home runs. */
	int[] home_runs;
	
	/** The visitteam runs. */
	int visitteam_runs;
	
	/** The hometeam runs. */
	int hometeam_runs;
	
	/** The total visitteam runs. */
	int total_visitteam_runs;
	
	/** The total hometeam runs. */
	int total_hometeam_runs;	
	
	/** The visitteam hits. */
	int visitteam_hits;
	
	/** The hometeam hits. */
	int hometeam_hits;
	
	/** The visitteam errors. */
	int visitteam_errors;
	
	/** The hometeam errors. */
	int hometeam_errors;
	
	/** The playlog. */
	int playlog=1;
	
	/** The total outs. */
	int total_outs;
	
	/** The gamelog. */
	GameLog gamelog;
	
	/** The gamelog transactions. */
	List<GameLog> gamelog_transactions;
	
	/** The gamelog scoring. */
	List<GameLog> gamelog_Scoring;
	
	/** The gamelog current. */
	List<GameLog> gamelog_Current;

	/** The is reset. */
	boolean isReset;
	
	/** The current play. */
	int currentPlay;
	
	/** The visit team. */
	Team visit_team;
	
	/** The home team. */
	Team home_team;
	
	/** The all teams. */
	List<Team> all_teams;
	
	/** The all teams standings. */
	List<Team> all_teams_standings;
	
	/** The On base. */
	Map<Integer, Hitter> OnBase;
	
	/** The visit hitters. */
	List<Hitter> visit_Hitters;
	
	/** The home hitters. */
	List<Hitter> home_Hitters;
	
	/** The visit pitchers. */
	List<Pitcher> visit_Pitchers;
	
	/** The home pitchers. */
	List<Pitcher> home_Pitchers;
	

	
	/** The current hitter. */
	Hitter current_Hitter;
	
	/** The current pitcher. */
	Pitcher current_Pitcher;	
	
	/** The current home pitcher. */
	Pitcher current_HomePitcher;
	
	/** The current visit pitcher. */
	Pitcher current_VisitPitcher;
	
	/** The current visit pitcherid. */
	int current_visit_pitcherid;
	
	/** The current home pitcherid. */
	int current_home_pitcherid;
	
	/** The current pitcher id. */
	int current_pitcher_id;
	
	/** The current hitter id. */
	int current_hitter_id;	
	
	/** The current result. */
	String current_result;
	
	/** The current vishitter index. */
	int current_vishitter_index;
	
	/** The current homhitter index. */
	int current_homhitter_index;
	
	/** The inningbreak. */
	//Set total number of innings played
	int inningbreak;
	
	/** The total hitters. */
	int total_hitters=6;

	/** The is scoredon BB. */
	boolean isScoredonBB=false;
	
	/** The frombase. */
	int frombase;
	
	/** The tobase. */
	int tobase;
	
	/** The switchinning. */
	boolean switchinning;
	
	/** The menu. */
	String[] menu= {"Singles", "Doubles", "Triples", "Home Run",
			"Takes Ball", "Take Strike", "Swinging Strike",
			"Ground Out", "Fly Out"};
	
	/** The current base situation. */
	String current_base_situation;
	
	/** The current base runner. */
	String current_base_runner;
	
	/** The advance runner. */
	boolean advanceRunner;
	

	/**
	 * Checks if is top.
	 *
	 * @return true, if is top
	 */
	public boolean isTop() {
		return top;
	}

	/**
	 * Sets the top.
	 *
	 * @param top the new top
	 */
	public void setTop(boolean top) {
		this.top = top;
	}


	/**
	 * Gets the inning.
	 *
	 * @return the inning
	 */
	public int getInning() {
		return inning;
	}

	/**
	 * Sets the inning.
	 *
	 * @param inning the new inning
	 */
	public void setInning(int inning) {
		this.inning = inning;
	}

	/**
	 * Gets the total visitteam runs.
	 *
	 * @return the total visitteam runs
	 */
	public int getTotal_visitteam_runs() {
		return total_visitteam_runs;
	}

	/**
	 * Sets the total visitteam runs.
	 *
	 * @param total_visitteam_runs the new total visitteam runs
	 */
	public void setTotal_visitteam_runs(int total_visitteam_runs) {
		this.total_visitteam_runs = total_visitteam_runs;
	}

	/**
	 * Gets the total hometeam runs.
	 *
	 * @return the total hometeam runs
	 */
	public int getTotal_hometeam_runs() {
		return total_hometeam_runs;
	}

	/**
	 * Sets the total hometeam runs.
	 *
	 * @param total_hometeam_runs the new total hometeam runs
	 */
	public void setTotal_hometeam_runs(int total_hometeam_runs) {
		this.total_hometeam_runs = total_hometeam_runs;
	}

	/**
	 * Gets the strikes.
	 *
	 * @return the strikes
	 */
	public int getStrikes() {
		return strikes;
	}

	/**
	 * Sets the strikes.
	 *
	 * @param strikes the new strikes
	 */
	public void setStrikes(int strikes) {
		this.strikes = strikes;
	}

	/**
	 * Gets the outs.
	 *
	 * @return the outs
	 */
	public int getOuts() {
		return outs;
	}

	/**
	 * Sets the outs.
	 *
	 * @param outs the new outs
	 */
	public void setOuts(int outs) {
		this.outs = outs;
	}

	/**
	 * Gets the balls.
	 *
	 * @return the balls
	 */
	public int getBalls() {
		return balls;
	}

	/**
	 * Sets the balls.
	 *
	 * @param balls the new balls
	 */
	public void setBalls(int balls) {
		this.balls = balls;
	}

	/**
	 * Gets the current hitter.
	 *
	 * @return the current hitter
	 */
	public Hitter getCurrent_Hitter() {
		return current_Hitter;
	}

	/**
	 * Sets the current hitter.
	 *
	 * @param current_Hitter the new current hitter
	 */
	public void setCurrent_Hitter(Hitter current_Hitter) {
		this.current_Hitter = current_Hitter;
	}

	/**
	 * Gets the visit hitters.
	 *
	 * @return the visit hitters
	 */
	public List<Hitter> getVisit_Hitters() {
		return visit_Hitters;
	}

	/**
	 * Sets the visit hitters.
	 *
	 * @param visit_Hitters the new visit hitters
	 */
	public void setVisit_Hitters(List<Hitter> visit_Hitters) {
		this.visit_Hitters = visit_Hitters;
	}

	/**
	 * Gets the home hitters.
	 *
	 * @return the home hitters
	 */
	public List<Hitter> getHome_Hitters() {
		return home_Hitters;
	}

	/**
	 * Sets the home hitters.
	 *
	 * @param home_Hitters the new home hitters
	 */
	public void setHome_Hitters(List<Hitter> home_Hitters) {
		this.home_Hitters = home_Hitters;
	}

	/**
	 * Gets the current home pitcher.
	 *
	 * @return the current home pitcher
	 */
	public Pitcher getCurrent_HomePitcher() {
		return current_HomePitcher;
	}

	/**
	 * Sets the current home pitcher.
	 *
	 * @param current_HomePitcher the new current home pitcher
	 */
	public void setCurrent_HomePitcher(Pitcher current_HomePitcher) {
		this.current_HomePitcher = current_HomePitcher;
	}

	/**
	 * Gets the current visit pitcher.
	 *
	 * @return the current visit pitcher
	 */
	public Pitcher getCurrent_VisitPitcher() {
		return current_VisitPitcher;
	}

	/**
	 * Sets the current visit pitcher.
	 *
	 * @param current_VisitPitcher the new current visit pitcher
	 */
	public void setCurrent_VisitPitcher(Pitcher current_VisitPitcher) {
		this.current_VisitPitcher = current_VisitPitcher;
	}

	/**
	 * Gets the current pitcher.
	 *
	 * @return the current pitcher
	 */
	public Pitcher getCurrent_Pitcher() {
		return current_Pitcher;
	}

	/**
	 * Sets the current pitcher.
	 *
	 * @param current_Pitcher the new current pitcher
	 */
	public void setCurrent_Pitcher(Pitcher current_Pitcher) {
		this.current_Pitcher = current_Pitcher;
	}

	/**
	 * Checks if is runners on base.
	 *
	 * @return true, if is runners on base
	 */
	public boolean isRunnersOnBase() {
		return RunnersOnBase;
	}

	/**
	 * Sets the runners on base.
	 *
	 * @param runnersOnBase the new runners on base
	 */
	public void setRunnersOnBase(boolean runnersOnBase) {
		RunnersOnBase = runnersOnBase;
	}

	/**
	 * Gets the on base.
	 *
	 * @return the on base
	 */
	public Map<Integer, Hitter> getOnBase() {
		return OnBase;
	}

	/**
	 * Sets the on base.
	 *
	 * @param onBase the on base
	 */
	public void setOnBase(Map<Integer, Hitter> onBase) {
		OnBase = onBase;
	}

	/**
	 * Gets the current base situation.
	 *
	 * @return the current base situation
	 */
	public String getCurrent_base_situation() {
		return current_base_situation;
	}

	/**
	 * Sets the current base situation.
	 *
	 * @param current_base_situation the new current base situation
	 */
	public void setCurrent_base_situation(String current_base_situation) {
		this.current_base_situation = current_base_situation;
	}

	/**
	 * Gets the current result.
	 *
	 * @return the current result
	 */
	public String getCurrent_result() {
		return current_result;
	}

	/**
	 * Sets the current result.
	 *
	 * @param current_result the new current result
	 */
	public void setCurrent_result(String current_result) {
		this.current_result = current_result;
	}
	
	
	/**
	 * Gets the visit pitchers.
	 *
	 * @return the visit pitchers
	 */
	public List<Pitcher> getVisit_Pitchers() {
		return visit_Pitchers;
	}

	/**
	 * Sets the visit pitchers.
	 *
	 * @param visit_Pitchers the new visit pitchers
	 */
	public void setVisit_Pitchers(List<Pitcher> visit_Pitchers) {
		this.visit_Pitchers = visit_Pitchers;
	}

	/**
	 * Gets the home pitchers.
	 *
	 * @return the home pitchers
	 */
	public List<Pitcher> getHome_Pitchers() {
		return home_Pitchers;
	}

	/**
	 * Sets the home pitchers.
	 *
	 * @param home_Pitchers the new home pitchers
	 */
	public void setHome_Pitchers(List<Pitcher> home_Pitchers) {
		this.home_Pitchers = home_Pitchers;
	}

	/**
	 * Gets the visit team.
	 *
	 * @return the visit team
	 */
	public Team getVisit_team() {
		return visit_team;
	}

	/**
	 * Sets the visit team.
	 *
	 * @param visit_team the new visit team
	 */
	public void setVisit_team(Team visit_team) {
		this.visit_team = visit_team;
	}

	/**
	 * Gets the home team.
	 *
	 * @return the home team
	 */
	public Team getHome_team() {
		return home_team;
	}

	/**
	 * Sets the home team.
	 *
	 * @param home_team the new home team
	 */
	public void setHome_team(Team home_team) {
		this.home_team = home_team;
	}
	
	/**
	 * Gets the all teams.
	 *
	 * @return the all teams
	 */
	public List<Team> getAll_teams() {
		return all_teams;
	}

	/**
	 * Sets the all teams.
	 *
	 * @param all_teams the new all teams
	 */
	public void setAll_teams(List<Team> all_teams) {
		this.all_teams = all_teams;
	}
	
	/**
	 * Gets the gamelog scoring.
	 *
	 * @return the gamelog scoring
	 */
	public List<GameLog> getGamelog_Scoring() {
		return gamelog_Scoring;
	}

	/**
	 * Sets the gamelog scoring.
	 *
	 * @param gamelog_Scoring the new gamelog scoring
	 */
	public void setGamelog_Scoring(List<GameLog> gamelog_Scoring) {
		this.gamelog_Scoring = gamelog_Scoring;
	}

	/**
	 * Gets the all teams standings.
	 *
	 * @return the all teams standings
	 */
	public List<Team> getAll_teams_standings() {
		return all_teams_standings;
	}

	/**
	 * Sets the all teams standings.
	 *
	 * @param all_teams_standings the new all teams standings
	 */
	public void setAll_teams_standings(List<Team> all_teams_standings) {
		this.all_teams_standings = all_teams_standings;
	}


	/**
	 * Gets the gamelog current.
	 *
	 * @return the gamelog current
	 */
	public List<GameLog> getGamelog_Current() {
		return gamelog_Current;
	}

	/**
	 * Sets the gamelog current.
	 *
	 * @param gamelog_Current the new gamelog current
	 */
	public void setGamelog_Current(List<GameLog> gamelog_Current) {
		this.gamelog_Current = gamelog_Current;
	}

	/**
	 * This is the main constructor for the Game class.
	 */
	
	
	public Game() {
		try {
			//Intizalize lists and maps
			visit_Hitters=new LinkedList<Hitter>();
			home_Hitters=new LinkedList<Hitter>();
			OnBase=new HashMap<Integer,Hitter>();
			gamelog_transactions=new LinkedList<GameLog>();
			
			//Reset
			top=true;
			balls=0;
			strikes=0;
			outs=0;
//		isWalk=false;
//		switchinning=false;
			isScoredonBB=false;
			isReset=false;
			scoreUpdated=false;
			currentPlay=1;
			setBasesEmpty();
			advanceRunner=false;
			
			visit_runs=new int[9];
			home_runs=new int[9];
			total_visitteam_runs=0;
			total_hometeam_runs=0;
			
			visitteam_runs=0;
			hometeam_runs=0;
			visitteam_runs=0;
			hometeam_runs=0;		
			
			inning=1;
			inningbreak=1;
			
			TeamDAO teamDAO=new TeamDAO();
			all_teams=teamDAO.getAllTeams();
			
			GameDAO gameDAO=new GameDAO();
			int result=gameDAO.truncateGameLog();
			
			String Output=(result==1)?"TABLE TRUNC":"TABLE NOT";
			System.out.println(Output);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Error at Game Constructor: " + e.getMessage());
		}
		
//		for(int i=1;i<OnBase.size()+1;i++) {
//			System.out.println("Runner on " + i + ": " + OnBase.get(i));
//		}
	}
	
	
	/**
	 * Get hitter and pitcher information based on team id and player_id.
	 *
	 * @param visit_team the visit team
	 * @param home_team the home team
	 * @return the pitcher DAO
	 */
	
	
	public void getPitcherDAO(int visit_team, int home_team) {
		PitcherDAO pitcherDAO=new PitcherDAO();
		TeamDAO teamDAO=new TeamDAO();

		try {
			
			List<Pitcher>visit= pitcherDAO.getPitcherByTeamID(visit_team);
			List<Pitcher> visit_pitchers=new LinkedList<Pitcher>(visit);
			visit_Pitchers=visit_pitchers;
			
			List<Pitcher>home= pitcherDAO.getPitcherByTeamID(home_team);
			List<Pitcher> home_pitchers=new LinkedList<Pitcher>(home);
			home_Pitchers=home_pitchers;
			
			this.visit_team=teamDAO.getTeamById(visit_team);
			this.home_team=teamDAO.getTeamById(home_team);
			
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	/**
	 * Get hitter and pitcher information based on team id and player_id.
	 *
	 * @param visit_team the visit team
	 * @param home_team the home team
	 * @param vis_pitcher the vis pitcher
	 * @param home_pitcher the home pitcher
	 */
	
	public void assignHittersDAO(int visit_team, int home_team, int vis_pitcher, int home_pitcher) {
		HitterDAO hitterDAO=new HitterDAO();
		PitcherDAO pitcherDAO=new PitcherDAO();
		
		try {
			List<Hitter> visit=hitterDAO.getAllHittersByTeamID(visit_team);
			List<Hitter> visit_hitters=new LinkedList<Hitter>(visit);
			visit_Hitters=visit_hitters;
			
			List<Hitter> home=hitterDAO.getAllHittersByTeamID(home_team);
			List<Hitter> home_hitters=new LinkedList<Hitter>(home);
			home_Hitters=home_hitters;
//			for (Hitter hitter : visit_hitters) {
//				System.out.format("%s has %d hits and %d rbi.%n", hitter.getFullName(),
//						hitter.getHits(),hitter.getRbi());
//			}
//			
//			System.out.println("===============");
//
//			for (Hitter hitter : home_hitters) {
//				System.out.format("%s has %d hits and %d rbi.%n", hitter.getFullName(),
//						hitter.getHits(),hitter.getRbi());
//			}
			
			current_VisitPitcher=pitcherDAO.getPitcherByID(visit_team, vis_pitcher);
			current_HomePitcher=pitcherDAO.getPitcherByID(home_team, home_pitcher);
			
			
			//Set the first visiting hitter
			current_vishitter_index=0;
			current_Hitter=visit_Hitters.get(current_vishitter_index);
			current_homhitter_index=-1 ;

			printTeams();
		
			System.out.println("LineUp Set.");	
			
			
//			System.out.format("%s has pitched %.1f innings and given up %d runs.%n", visit_pitcher.getFullname(),
//					visit_pitcher.getInnings(),visit_pitcher.getRuns());
//			
//			System.out.format("%s has pitched %.1f innings and given up %d runs.%n", home_pitcher.getFullname(),
//					home_pitcher.getInnings(),home_pitcher.getRuns());
			
			
		} catch (ClassNotFoundException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Error msg: " +e.getMessage());
		}
	}
	
	/**
	 * Checks if is bases empty.
	 *
	 * @return true, if is bases empty
	 */
	public boolean isBasesEmpty() {
		
		
		if(OnBase.get(1)==null && OnBase.get(2)==null && OnBase.get(3)==null) {
			return true;
		}else {
			return false;
		}
		
	}
	

	/**
	 * Get profile of a baseball hitter.
	 *
	 * @param player_id the player id
	 * @return the hitter profile
	 */
	public Hitter getHitterProfile(int player_id) {
		
		
		
		for (Hitter hitter : visit_Hitters) {
			if(hitter.getPlayer_id()==player_id)
				return hitter;
		}
		
		for (Hitter hitter : home_Hitters) {
			if(hitter.getPlayer_id()==player_id)
				return hitter;			
		}
		
		return null;
	}
	
	
	/**
	 * Get game log of a baseball hitter.
	 *
	 * @param player_id the player id
	 * @return the hitter game log
	 */
	public List<GameLog> getHitterGameLog(int player_id) {
		GameDAO gameDAO=new GameDAO();
		
		try {
			
			return gameDAO.getGameLogCurrentHitter(player_id);
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("EX: " +e.getMessage());
		}
		return null;
	}
	
	
	/**
	 * Assign Hitters to a list which is at beginning.
	 *
	 * @param visit_team the visit team
	 * @param home_team the home team
	 * @param vis_pitcher the vis pitcher
	 * @param home_pitcher the home pitcher
	 */
	public void assignHitters(int visit_team, int home_team, int vis_pitcher, int home_pitcher) {
		//Get player's data
		
		try {
			String players_array[]=getFiles("src/Players.csv").split("\n");
			String pitchers_array[]=getFiles("src/Pitchers.csv").split("\n");
			
			int i=0;
			//Loop thorugh every player
			for(;i<players_array.length;i++) {
				if(i==0)
					continue;
				
				//Get data field for each player
				String player_data[]=players_array[i].split(",");
				
				int playerId=Integer.parseInt(player_data[0]);
				int teamId=Integer.parseInt(player_data[1]);
				String playerName=player_data[2];
				int atBats=Integer.parseInt(player_data[3]);;
				int runs=Integer.parseInt(player_data[4]);;
				int hits=Integer.parseInt(player_data[5]);;
				int doubles=Integer.parseInt(player_data[6]);;
				int homeRuns=Integer.parseInt(player_data[7]);;
				int rbi=Integer.parseInt(player_data[8]);;			
				int walks=Integer.parseInt(player_data[9]);;
				int strikeouts=Integer.parseInt(player_data[10]);;
				
				//Check each player's team
				if(teamId==visit_team) {
					visit_Hitters.add(new Hitter(playerId, teamId, 
							playerName, atBats, runs, hits, doubles, 
							homeRuns, rbi, walks,strikeouts));
				}else if(teamId==home_team) {
					home_Hitters.add(new Hitter(playerId, teamId, 
							playerName, atBats, runs, hits, doubles, 
							homeRuns, rbi, walks,strikeouts));
				}
			}
			
			for(i=0;i<pitchers_array.length;i++) {
				if(i==0)
					continue;
				
				//Get data field for each player
				String pitcher_data[]=pitchers_array[i].split(",");
				int playerId=Integer.parseInt(pitcher_data[0]);
				int teamId=Integer.parseInt(pitcher_data[1]);
				String Name=pitcher_data[2];			
				int wins=Integer.parseInt(pitcher_data[3]);
				int loss=Integer.parseInt(pitcher_data[4]);
				float innings=Float.parseFloat(pitcher_data[5]);
				int hits=Integer.parseInt(pitcher_data[6]);
				int runs=Integer.parseInt(pitcher_data[7]);
				int walks=Integer.parseInt(pitcher_data[8]);
				int strikeouts=Integer.parseInt(pitcher_data[9]);
				
				//Assign starting pitcher
				if(playerId==vis_pitcher) {
					current_VisitPitcher=new Pitcher(playerId, teamId, Name, 
							wins, loss, innings, hits, runs, walks, strikeouts);
				}else if(playerId==home_pitcher) {
					current_HomePitcher=new Pitcher(playerId, teamId, Name, 
							wins, loss, innings, hits, runs, walks, strikeouts);
				}
				
				//Set the first visiting hitter
				current_vishitter_index=0;
				current_Hitter=visit_Hitters.get(current_vishitter_index);
				current_homhitter_index=-1 ;
			}
			printTeams();
			
			System.out.println("LineUp Set.");			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("EX: " +e.getMessage());
		}

	}
	
	/**
	 * Prints the teams.
	 */
	void printTeams() {
		
		System.out.format("Starting Pitchers: %s vs %s.%n", current_HomePitcher.getFullname(),
				current_VisitPitcher.getFullname());
		System.out.println("======Visiting Team========");
		for (Hitter hitter : visit_Hitters) {
			System.out.format("%s has %d hits and %d rbi.%n", hitter.getFullName(),
					hitter.getHits(),hitter.getRbi());
		}

		System.out.println("======Home Team==========");
		for (Hitter hitter : home_Hitters) {
			System.out.format("%s has %d hits and %d rbi.%n", hitter.getFullName(),
					hitter.getHits(),hitter.getRbi());
		}
	}
	
	
	/**
	 * Update each array with run scored in that inning.
	 *
	 * @param inning the inning
	 */
	void updateScoreBoard(int inning) {		
		visit_runs[inning-1]=visitteam_runs;
		home_runs[inning-1]=hometeam_runs;
		
		total_visitteam_runs=0;
		total_hometeam_runs=0;
		
		//Go through entire array and get total runs
		for(int i=0;i<inning;i++) {
			total_visitteam_runs+=visit_runs[i];
		}
		
		for(int i=0;i<inning;i++) {
			total_hometeam_runs+=home_runs[i];
		}
	}
	
	/**
	 * Get total score.
	 *
	 * @return the total scores
	 */
	void getTotalScores() {
		
		total_visitteam_runs=0;
		total_hometeam_runs=0;
		
		for(int i=0;i<inning;i++) {
			total_visitteam_runs+=visit_runs[i];
			System.out.print(visit_runs[i] + " ");
		}
		
		System.out.print("Total_Visit: " + total_visitteam_runs);
		
		System.out.println();
		
		for(int i=0;i<inning;i++) {
			total_hometeam_runs+=home_runs[i];
			System.out.print(home_runs[i] + " ");
		}
		
		System.out.print("Total_Home: " + total_hometeam_runs);
	}
	
	
	/**
	 * Make Map null on each base.
	 */
	void setBasesEmpty() {
		RunnersOnBase=false;
		OnBase.put(1, null);
		OnBase.put(2, null);
		OnBase.put(3, null);		
	}
	
	/**
	 * Check if game is over after each transaction.
	 *
	 * @return true, if successful
	 */
	public boolean checkifGameOver() {
		boolean gameOver=false;
		
		//updateScoreBoard(inning);
		
		//Switch team hitter if there are three outs.
		if(outs==3) {
			System.out.println("THERE ARE THREE OUTS!!!");
			//Reset and empty bases.
			outs=0;
			setBasesEmpty();
			
			//Switch team hitters
			if(top) {
				outs=0;
				System.out.println("********HOME TEAM SWITCH***********");
				top=false;
			}else {
				outs=0;
				System.out.println("********VISIT TEAM SWITCH***********");				
				top=true;
				inning++;
				
				//Reset
				visitteam_runs=0;
				hometeam_runs=0;
			}

			//Get Next Hitter on other team when three outs
			get_currentHitter();
		}

		
		TeamDAO teamDAO=new TeamDAO();
		
		//Check if game is over when inning is past.
		if(inning>inningbreak && total_visitteam_runs==total_hometeam_runs) {
			System.out.println("TIE GAME!!!");
			gameOver=true;			
		}else if(top==false && inning==inningbreak && total_visitteam_runs<total_hometeam_runs){
			//Hone team wins
			System.out.println("Home Team Wins!!!");
			gameOver=true;
		}else if(inning>inningbreak && total_visitteam_runs>total_hometeam_runs) {
			//Visit Team wins
			System.out.println("Visitng Team Wins!!!");
			gameOver=true;			
		}
		

		int reult=0;
		
		try {
			
			System.out.println("Enter try for update team");
			
			if(gameOver && total_visitteam_runs>total_hometeam_runs) {
				reult=teamDAO.updateTeamWins(visit_team.getTeam_id());
				System.out.println("Update Wins:" + reult);
				reult=teamDAO.updateTeamLosses(home_team.getTeam_id());
				System.out.println("Update Losses:" + reult);
				
				
			}else if(gameOver && total_visitteam_runs<total_hometeam_runs) {
				reult=teamDAO.updateTeamWins(home_team.getTeam_id());
				System.out.println("Update Wins:" + reult);				
				reult=teamDAO.updateTeamLosses(visit_team.getTeam_id());
				System.out.println("Update Losses:" + reult);
				

			}		
			
			visit_team=teamDAO.getTeamById(visit_team.getTeam_id());
			home_team=teamDAO.getTeamById(home_team.getTeam_id());
			
			System.out.println("Exit try for update team");
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("checkifGameOver method " + e.getMessage());
		}


	
		return gameOver;
	}
	
	/**
	 * Set next current Hitter Object.
	 *
	 * @return the current hitter
	 */
	void get_currentHitter() {
		//Reset Count
		balls=0;
		strikes=0;
		
		//get next current hitter
		if(top==true) {
			//Reset or else get next hitter
			if(current_vishitter_index==visit_Hitters.size()-1)
				current_vishitter_index=0;
			else
				current_vishitter_index++;
			
			current_Hitter=visit_Hitters.get(current_vishitter_index);
		}else {
			if(current_homhitter_index==home_Hitters.size()-1)
				current_homhitter_index=0;
			else
				current_homhitter_index++;
			
			current_Hitter=home_Hitters.get(current_homhitter_index);
		}
	}
	
	/**
	 * Ask user for input regarding play transaction.
	 *
	 * @return the game menu
	 */
	public void getGameMenu() {
		//Get the current hitter
		
		if(top==true) {
			current_Pitcher=current_HomePitcher;
		}else {
			current_Pitcher=current_VisitPitcher;
		}
		
		System.out.println("==============");
		System.out.println("*******************");
		System.out.println("Current Hitter: " + current_Hitter.getFullName());
		
		//Compute Bating Avg
		double avg=(float)current_Hitter.getHits()/current_Hitter.getAt_bats();
		String pattern=".###";
		DecimalFormat decimalFormat=new DecimalFormat(pattern);
		String format=decimalFormat.format(avg);
		
		//Show stats
		System.out.format("Avg: %s has %d HRS and %d RBI.%n", format,
				current_Hitter.getHomeruns(),current_Hitter.getRbi());
		
		//Current Base Situation
		for(int i=1;i<=OnBase.size();i++) {
			if(OnBase.get(i)!=null) {
				Hitter runner=OnBase.get(i);
				System.out.print(runner.getFullName() + " is on " + i + ". ");
			}
		}
		System.out.println("\n*******************");
		getTotalScores();	
		System.out.print("\n");
		//System.out.format("Visit: %d Home: %d.%n", total_visitteam_runs, total_hometeam_runs);
		System.out.format("%s %d -- ", (top)?"Top":"Bottom", inning);
		System.out.format("Balls: %d Strikes: %d Outs: %d.%n", balls,strikes,outs);

		System.out.println("==============");
		//Game Menu
		StringBuilder menuOptions=new StringBuilder();
		String[] menu= {"Singles", "Doubles", "Triples", "Home Run",
			"Takes Ball", "Take Strike", "Swinging Strike",
			"Ground Out", "Fly Out"};
		
		String build="";
		for(int i=0;i<menu.length;i++) {
			if(i==4 || i==7 || i==9)
				build+="\n";
			
			build+=i+1 + "-" + menu[i] + " ";
		}
			
		menuOptions.append(build);

		System.out.println("Pick an option:");
		System.out.println(menuOptions);		
	}
	
	/**
	 * 	Record transaction based on user choice and go to next transaction.
	 *
	 * @param pick the pick
	 */
	public void recordTransaction(int pick) {

		String result;
		String pitcherName;
		int pitcher_id;
		int hitter_id;

		try {
			if(top==true) {
				pitcherName=current_HomePitcher.getFullname();
				current_pitcher_id=current_HomePitcher.getPitcher_id();
				//System.out.println("HOME PITCHER");
			}else {
				pitcherName=current_VisitPitcher.getFullname();
				current_pitcher_id=current_VisitPitcher.getPitcher_id();
						
				//System.out.println("VISIT PITCHER");
			}
			
			//Get hitter name and id
			current_hitter_id=current_Hitter.getPlayer_id();
			current_result=current_Hitter.getFullName() + " " + menu[pick-1].toLowerCase() + " against "
					+ pitcherName;		
			
			//Check options
			//Check for hits
			if(pick>=1 && pick<=4) {
				isReset=true;
				//Score All if "Home Run"
				if(pick==4)
					scoreAll();
				
				//If other hits, advance the runners.
				if(RunnersOnBase) {
					//setBaseSituations(pick);
				}
				
				//If player gets hits, put him on base
				if(pick==1) {
					updateHitterStats(current_Hitter, 1, 1, 0, 0, 0, 0, 0, 0);
					OnBase.put(1, current_Hitter);
				}else if (pick==2) {
					updateHitterStats(current_Hitter, 1, 1, 0, 1, 0, 0, 0, 0);
					OnBase.put(2, current_Hitter);
				}else if (pick==3) {
					updateHitterStats(current_Hitter, 1, 1, 0, 0, 0, 0, 0, 0);
					OnBase.put(3, current_Hitter);
				}
				if(pick!=4) {
					RunnersOnBase=true;
				}
				
				//Get Next hitter
				get_currentHitter();
			}else if (pick>=8 && pick<=9) {
				//Record outs.
				isReset=true;
				outs++;
				updateHitterStats(current_Hitter, 1, 0, 0, 0, 0, 0, 0, 0);
				
				//Get Next hitter
				if(outs<3)
					get_currentHitter();
			}else if(pick==5) {
				balls++;
				//if balls=4, then the player walks
				if(balls==4) {
					isReset=true;
					if(RunnersOnBase) {
						//setBaseSituations(scanner);
					}
					
					//If player walks, put him on base
					//OnBase.put(1, current_Hitter);
					setBaseSituation(1, current_Hitter);
					updateHitterStats(current_Hitter, 0, 0, 0, 0, 0, 0, 1, 0);

					RunnersOnBase=true;
					get_currentHitter();									
				}
			}else if(pick==6 || pick==7) {
				strikes++;
				//if strikes=3, then the player strikes out
				if(strikes==3) {
					isReset=true;
					updateHitterStats(current_Hitter, 1, 0, 0, 0, 0, 0, 0, 1);
					outs++;
					if(outs<3)
						get_currentHitter();
				}
			}	
			
			//Update Scoreboard
			updateScoreBoard(inning);

			//Record transaction and put into collection.
			//currentPlay
	
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("--------Error at recordTransaction: " + e.getMessage());
		}
		//Get pitcher name and id

	}
	
	/**
	 * Add game transaction data to the database.
	 */
	
	public void updateTransaction() {
		
		
		
		GameLog gameLog=new GameLog(playlog,currentPlay, current_result,inning,top,balls,strikes,outs,total_visitteam_runs,
				total_hometeam_runs,current_hitter_id,current_pitcher_id,scoreUpdated);
		
		gamelog_transactions.add(gameLog);
		scoreUpdated=false;
		
		
		GameDAO gameDAO=new GameDAO();
		
		//gameDAO.addGameLog(playlog, current_play, result_outcome, inning, top, balls, strikes, outs, visit_runs, home_runs, hitter_id, pitcher_id, score_updated);
		
		try {
			int added_result=gameDAO.addGameLog(gameLog.getPlayseries(), gameLog.getCurrentplay(), gameLog.getResult(), gameLog.getInning(), gameLog.isTop(), 
					gameLog.getBalls(), gameLog.getStrikes(), gameLog.getOuts(), gameLog.getVisitingteam_runs(), gameLog.getHometeam_runs(), 
					gameLog.getHitter_id(), gameLog.getPitcher_id(), gameLog.isScore_updated());
			
			gamelog_Current=gameDAO.getGameLogCurrent(current_hitter_id, playlog-8);
			
			System.out.println("======= Result Added " + added_result);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			
			System.out.println("Error at update Transaction: " + e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Error at update Transaction: " + e.getMessage());
		}finally {
			//Reset is true
			if(isReset) {
				currentPlay=1;
				isReset=false;
			}else
				currentPlay++;
			
			playlog++;	
		}
		
		//Play_count,result, inning,top,balls,strike,out,visit_score,home_score, hitterid,pitcher_id
		//System.out.format("Ball: %d Strike: %d Out:%d Visit: %d Home: %d.%n", balls,
		//		strikes,outs,total_visitteam_runs,total_hometeam_runs);
		//System.out.println("Play " + playlog + ": " +result);
	
	}
	
	
	
	
	
	/**
	 * if player hits home run, all players score
	 * Update hitter statistics.
	 */
	public void scoreAll() {
		int run_scored=0;
		
		//Empty the base
		for(int i=1;i<=OnBase.size();++i) {
			if(OnBase.get(i) != null) {
				Hitter runner=OnBase.get(i);
				updateHitterStats(runner, 0, 0, 1, 0, 0, 0, 0, 0);
				OnBase.put(i, null);
				run_scored++;
			}
		}
		
		//bases are empty
		RunnersOnBase=false;
		setBasesEmpty();
		
		//int rbi =current_Hitter.getRbi();
		int rbi=++run_scored;

		updateHitterStats(current_Hitter, 1, 1, 1, 0, 1, rbi, 0, 0);
		
		//Update ScoreBoard
		scoreUpdated=true;
		if(top) {
			visitteam_runs+=run_scored;
		}else
			hometeam_runs+=run_scored;	
	}
	
	/**
	 * Update Hitter Stats for Today Game.
	 *
	 * @param current_Hitter the current hitter
	 * @param at_bat the at bat
	 * @param hits the hits
	 * @param runs the runs
	 * @param doubles the doubles
	 * @param hr the hr
	 * @param rbi the rbi
	 * @param walks the walks
	 * @param so the so
	 */
	void updateHitterStats(Hitter current_Hitter,int at_bat,int hits, 
			int runs, int doubles, int hr, int rbi,int walks, int so) {
		//Get stats and update with parameters
		int today_ab=current_Hitter.getTodayStats().getAt_bats()+at_bat;
		int today_hit=current_Hitter.getTodayStats().getHits()+hits;
		int today_run=current_Hitter.getTodayStats().getRuns()+runs;		
		int today_double=current_Hitter.getTodayStats().getDoubles()+doubles;
		int today_homerun=current_Hitter.getTodayStats().getHomeruns()+hr;
		int today_rbi=current_Hitter.getTodayStats().getRbi()+rbi;
		int today_walk=current_Hitter.getTodayStats().getWalks()+walks;
		int today_strike=current_Hitter.getTodayStats().getStrikeouts()+so;
		
		//Set the new stat values
		current_Hitter.getTodayStats().setAt_bats(today_ab);
		current_Hitter.getTodayStats().setHits(today_hit);
		current_Hitter.getTodayStats().setRuns(today_run);
		current_Hitter.getTodayStats().setDoubles(today_double);
		current_Hitter.getTodayStats().setHomeruns(today_homerun);
		current_Hitter.getTodayStats().setRbi(today_rbi);
		current_Hitter.getTodayStats().setWalks(today_walk);
		current_Hitter.getTodayStats().setStrikeouts(today_strike);
	}
	
	/**
	 * Advance runner if not home run.
	 *
	 * @param hit the hit
	 * @param base the base
	 * @return the base situations
	 */
	public void getBaseSituations(int hit, int base){
		
		current_base_situation="";
				//Get the player on base.
		
		if(OnBase.get(base)!=null) {
			Hitter runner=OnBase.get(base);
					

			current_base_situation=runner.getFullName() + " on " + base + " goes to: \n";
							//System.out.format("%s on %d goes to: ", runner.getFullName(), i);
						
			//Runner on 2nd
			if (base==2) { 
				//Single and empty first
				if(hit==1 && OnBase.get(1)==null) {
					current_base_situation+="2-Stay 3-Third 4-Home";
					//System.out.println("2-Stay 3-Third 4-Home");
				}else if(hit==1 && OnBase.get(1)!=null) {
					current_base_situation+="3-Third 4-Home";
					//System.out.println("3-Third 4-Home");
				}else if (hit==2) {
					advanceRunner(base, 4);
					current_base_situation="";
					//current_base_situation+="3-Third 4-Home";
					//System.out.println("3-Third 4-Home");
				}else if (hit==3) {
					advanceRunner(base, 4);
					current_base_situation="";
					//current_base_situation+="4-Home";
					//System.out.println("4-Home");
				}
			}else if (base==1) {
				if(hit==1) {
					current_base_situation+="2-Second 3-Third 4-Home";
					//System.out.println("2-Second 3-Third 4-Home");
				}else if (hit==2) {
					current_base_situation+="3-Third 4-Home";
					//System.out.println("3-Third 4-Home");
				}else if (hit==3) {
					advanceRunner(base, 4);
					current_base_situation="";
					//System.out.println("4-Home");
				}
			}else if(base==3) {
				advanceRunner(base, 4);
				current_base_situation="";				
			}
		}
			
//		if(ballGame.onThird!=null) {
//			runner=ballGame.onThird;
//			System.out.println(runner.getFullName() + " on third goes to:");
//			System.out.println("4- Home");
//			base=scanner.nextInt();
//			if (base==4 && current_Top==true) {
//				ballGame.vist_score++;
//			}else if (base==4 && current_Top==false) {
//				ballGame.home_score++;
//			}
//			ballGame.onThird=null;
//		}
	}
	
	/**
	 * if current_hitter walks, advance runners.
	 *
	 * @param base the base
	 * @param hitter the hitter
	 */	
	public void setBaseSituation(int base,Hitter hitter) {
		
		isScoredonBB=false;
		
		if(base==4) {
			updateHitterStats(hitter, 0, 0, 1, 0, 0, 0, 0, 0);
			scoreUpdated=true;
			isScoredonBB=true;
			if(top) {
				visitteam_runs++;
			}else
				hometeam_runs++;
			
			OnBase.put(4, null);
			
			return;
		}		

		//Get the runner on each base
		Hitter runner=OnBase.get(base);
		
		if(runner!=null) {
			setBaseSituation(base+1,runner);
		}
		
		//Update rbi
		if(isScoredonBB && base==1)
			updateHitterStats(hitter, 0, 0, 0, 0, 0, 1, 0, 0);
		
		//Put runner on base
		System.out.println(hitter.getFullName() + " goes to " + base);
		OnBase.put(base, hitter);
	}

	
	/**
	 * Advance the runner from a base to the another base.
	 *
	 * @param frombase the frombase
	 * @param tobase the tobase
	 */
	
	public void advanceRunner(int frombase, int tobase) {
		//Get runner from base he start on
		Hitter runner=OnBase.get(frombase);
		
		//If runner score
		if(tobase==4) {
			//update run stats
			scoreUpdated=true;
//			int runscored=runner.getRuns();
//			runner.setRuns(++runscored);
			
			int runscored=runner.getTodayStats().getRuns();
			runner.getTodayStats().setRuns(++runscored);
			
			//Update hitter rbi
			int rbi=current_Hitter.getTodayStats().getRbi();
			current_Hitter.getTodayStats().setRbi(++rbi);
			
			//Update ScoreBoard
			if(top) {
				visitteam_runs++;
			}else
				hometeam_runs++;
			
			//update frombase
			OnBase.put(frombase, null);
		}else if (tobase==3) {
			//if runner goes to third
			//update OnBase
			OnBase.put(tobase, runner);
			
			if(frombase!=tobase)
				OnBase.put(frombase, null);
		}else if(tobase==2) {
			//if runner goes to second
			//update OnBase
			OnBase.put(tobase, runner);
			
			if(frombase!=tobase)
				OnBase.put(frombase, null);			
		}else if(tobase==1) {
			//if runner goes to first
			//update OnBase
			OnBase.put(tobase, runner);
			
			if(frombase!=tobase)
				OnBase.put(frombase, null);			
		}
	}
	
	
	/**
	 * Get Scoring Summary and Team Standings in the game.
	 *
	 * @return the scoring summary
	 */
	
	
	public void getScoringSummary() {
		
		GameDAO gameDAO=new GameDAO();
		TeamDAO teamDAO=new TeamDAO();
		
		try {
			
			gamelog_Scoring=gameDAO.getGameLogScore("true");
			all_teams_standings=teamDAO.getTeamStandings();
			
			
			//System.out.println("Size of GameLOg:" + gamelog_Scoring.size());
			
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error at getScoringSummary " + e.getMessage());
		}
	}
	
	
	/**
	 * Print final score.
	 *
	 * @return the final score
	 */
	
	public void getFinalScore() {
		System.out.println("FINAL SCORE");
		System.out.format("Visit:%d Home:%d %n", total_visitteam_runs,
				total_hometeam_runs);
		
		System.out.println("======Visiting Team========");
		
		System.out.println("AB H R 2B HR RBI BB SO");
		for (Hitter hitter : visit_Hitters) {
			System.out.format("%d  %d %d %d  %d  %d   %d  %d -- %s %n",
					hitter.getTodayStats().getAt_bats(),hitter.getTodayStats().getHits(),
					hitter.getTodayStats().getRuns(),
					hitter.getTodayStats().getDoubles(),hitter.getTodayStats().getHomeruns(),
					hitter.getTodayStats().getRbi(),hitter.getTodayStats().getWalks(),
					hitter.getTodayStats().getStrikeouts(),hitter.getFullName());
		}

		System.out.println("======Home Team==========");
		
		System.out.println("AB H R 2B HR RBI BB SO");
		for (Hitter hitter : home_Hitters) {
			System.out.format("%d  %d %d %d  %d  %d   %d  %d -- %s %n",
					hitter.getTodayStats().getAt_bats(),hitter.getTodayStats().getHits(),
					hitter.getTodayStats().getRuns(),
					hitter.getTodayStats().getDoubles(),hitter.getTodayStats().getHomeruns(),
					hitter.getTodayStats().getRbi(),hitter.getTodayStats().getWalks(),
					hitter.getTodayStats().getStrikeouts(),hitter.getFullName());
		}
	}
	
	/**
	 * Gets the files.
	 *
	 * @param fileName the file name
	 * @return the files
	 */
	String getFiles(String fileName) {
		String teamVisit;
		teamVisit=FileReaderCode.readCsvFile(fileName);
		
		return teamVisit;
	}
	
	
	/**
	 * Save data to a text file.
	 *
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	
	public void savePlayers() throws IOException {
		String FileRead="";
		String playerdata = "";
		String gameLogdata = "";
		String CD=",";
		String NL="\n";

		try {
			int i=1;

			//Output player data
			playerdata=playerdata.concat("Hitter_ID"+CD);
			playerdata=playerdata.concat("AB"+CD);
			playerdata=playerdata.concat("H"+CD);
			playerdata=playerdata.concat("R"+CD);
			playerdata=playerdata.concat("2B"+CD);
			playerdata=playerdata.concat("HR"+CD);			
			playerdata=playerdata.concat("RBI"+CD);
			playerdata=playerdata.concat("BB"+CD);
			playerdata=playerdata.concat("SO"+NL);
			
			for (Hitter hitter : visit_Hitters) {
				playerdata=playerdata.concat(hitter.getPlayer_id()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getAt_bats()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getHits()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getRuns()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getDoubles()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getHomeruns()+CD);			
				playerdata=playerdata.concat(hitter.getTodayStats().getRbi()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getWalks()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getStrikeouts()+NL);
			}
			
			for (Hitter hitter : home_Hitters) {
				playerdata=playerdata.concat(hitter.getPlayer_id()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getAt_bats()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getHits()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getRuns()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getDoubles()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getHomeruns()+CD);			
				playerdata=playerdata.concat(hitter.getTodayStats().getRbi()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getWalks()+CD);
				playerdata=playerdata.concat(hitter.getTodayStats().getStrikeouts()+NL);
			}
			
			i=1;

			//Output Game Log Data
			gameLogdata=gameLogdata.concat("PlaySeries"+CD);
			gameLogdata=gameLogdata.concat("CurrentPlay"+CD);
			gameLogdata=gameLogdata.concat("Result"+CD);
			gameLogdata=gameLogdata.concat("Inning"+CD);
			gameLogdata=gameLogdata.concat("Top"+CD);
			gameLogdata=gameLogdata.concat("Balls"+CD);
			gameLogdata=gameLogdata.concat("Strikes"+CD);
			gameLogdata=gameLogdata.concat("Outs"+CD);
			gameLogdata=gameLogdata.concat("Visitingteam_runs"+CD);
			gameLogdata=gameLogdata.concat("Hometeam_runs"+CD);
			gameLogdata=gameLogdata.concat("Hitter_id"+CD);
			gameLogdata=gameLogdata.concat("Pitcher_id"+CD);
			gameLogdata=gameLogdata.concat("Score_updated"+NL);
			
			for (GameLog gameLog : gamelog_transactions) {
				if(i==gamelog_transactions.size()) {
					gameLogdata=gameLogdata.concat(gameLog.getPlayseries()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getCurrentplay()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getResult()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getInning()+CD);
					gameLogdata=gameLogdata.concat(gameLog.isTop()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getBalls()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getStrikes()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getOuts()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getVisitingteam_runs()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getHometeam_runs()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getHitter_id()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getPitcher_id()+CD);
					gameLogdata=gameLogdata.concat(gameLog.isScore_updated()+"");
//						gameLog.getResult()+CD+gameLog.getInning()+CD+gameLog.getBalls()+CD+
//						gameLog.getStrikes()+CD+gameLog.getOuts()+CD+gameLog.getVisitingteam_runs()
//						+CD+gameLog.getHometeam_runs()+CD+gameLog.getPitcher_id()+CD);
				}else {
//				new GameLog(playlog,currentPlay, result,inning,top,balls,strikes,outs,total_visitteam_runs,
//						total_hometeam_runs,hitter_id,pitcher_id));
					gameLogdata=gameLogdata.concat(gameLog.getPlayseries()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getCurrentplay()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getResult()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getInning()+CD);
					gameLogdata=gameLogdata.concat(gameLog.isTop()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getBalls()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getStrikes()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getOuts()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getVisitingteam_runs()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getHometeam_runs()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getHitter_id()+CD);
					gameLogdata=gameLogdata.concat(gameLog.getPitcher_id()+CD);
					gameLogdata=gameLogdata.concat(gameLog.isScore_updated()+NL);
					
				}
				i++;
			}
			
			FileReaderCode.WriteFileCSV("src/playerdata.csv", playerdata);
			FileReaderCode.WriteFileCSV("src/gamelog.csv", gameLogdata);
			System.out.println("File saved!!!!!!");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Error saving Game Log Data");;
		}
		
	}
}
