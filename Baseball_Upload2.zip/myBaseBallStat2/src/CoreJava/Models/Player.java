package CoreJava.Models;


// TODO: Auto-generated Javadoc
/**
 * 
 * This is the Player class which holds all the relevant data for each game transaction player. 
 * 
 * @author Greg Kim
 *
 */



public class Player {
	
	/** The player id. */
	int player_id;
	
	/** The team id. */
	int team_id;
	
	/** The full name. */
	String fullName;
	
	/** The at bats. */
	int at_bats;
	
	/** The hits. */
	int hits;
	
	/** The runs. */
	int runs;
	
	/** The doubles. */
	int doubles;
	
	/** The homeruns. */
	int homeruns;
	
	/** The rbi. */
	int rbi;
	
	/** The walks. */
	int walks;
	
	/** The strikeouts. */
	int strikeouts;
	
	/** The today stats. */
	Player todayStats;

	/**
	 * Instantiates a new player.
	 */
	public Player() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Instantiates a new player.
	 *
	 * @param player_id the player id
	 * @param team_id the team id
	 * @param fullName the full name
	 * @param at_bats the at bats
	 * @param runs the runs
	 * @param hits the hits
	 * @param doubles the doubles
	 * @param homeruns the homeruns
	 * @param rbi the rbi
	 * @param walks the walks
	 * @param strikeouts the strikeouts
	 */
	public Player(int player_id, int team_id, String fullName, int at_bats, int runs, int hits, int doubles,
			int homeruns, Integer rbi,int walks, int strikeouts) {
		this.player_id = player_id;
		this.team_id = team_id;
		this.fullName = fullName;
		this.at_bats = at_bats;
		this.runs = runs;
		this.hits = hits;
		this.doubles = doubles;
		this.homeruns = homeruns;
		this.rbi=rbi;
		this.walks = walks;
		this.strikeouts = strikeouts;
		this.todayStats=new Player();
	}
	
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object object) {
		if(object instanceof Hitter) {
			Hitter other=(Hitter) object;
			boolean SamePlayerId=(this.player_id ==other.getPlayer_id());
			boolean SameTeamId=(this.team_id==other.getTeam_id());
			boolean SameName=this.fullName.equals(other.getFullName());
			boolean SameAtBats=(this.at_bats==other.getAt_bats());
			boolean SameHits=(this.hits==other.getHits());
			boolean SameRuns=(this.runs==other.getRuns());
			boolean SameDoubles=(this.doubles==other.getDoubles());
			boolean SameHR=(this.homeruns==other.getHomeruns());
			boolean SameRBI=(this.rbi==other.getRbi());
			boolean SameWalks=(this.walks==other.getWalks());
			boolean SameSO=(this.strikeouts==other.getStrikeouts());
			
			if(SamePlayerId && SameTeamId && SameName && SameAtBats && SameHits && SameRuns && SameDoubles && SameHR
					&& SameRBI && SameWalks && SameSO)
				return true;
			else
				return false;
			
		}else
			return false;
		
	}
	

	/**
	 * Gets the player id.
	 *
	 * @return the player id
	 */
	public int getPlayer_id() {
		return player_id;
	}
	
	/**
	 * Sets the player id.
	 *
	 * @param player_id the new player id
	 */
	public void setPlayer_id(int player_id) {
		this.player_id = player_id;
	}
	
	/**
	 * Gets the full name.
	 *
	 * @return the full name
	 */
	public String getFullName() {
		return fullName;
	}
	
	/**
	 * Sets the full name.
	 *
	 * @param fullName the new full name
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	} 
	
	/**
	 * Gets the at bats.
	 *
	 * @return the at bats
	 */
	public int getAt_bats() {
		return at_bats;
	}
	
	/**
	 * Sets the at bats.
	 *
	 * @param at_bats the new at bats
	 */
	public void setAt_bats(int at_bats) {
		this.at_bats = at_bats;
	}
	
	/**
	 * Gets the hits.
	 *
	 * @return the hits
	 */
	public int getHits() {
		return hits;
	}
	
	/**
	 * Sets the hits.
	 *
	 * @param hits the new hits
	 */
	public void setHits(int hits) {
		this.hits = hits;
	}
	
	/**
	 * Gets the doubles.
	 *
	 * @return the doubles
	 */
	public int getDoubles() {
		return doubles;
	}
	
	/**
	 * Sets the doubles.
	 *
	 * @param doubles the new doubles
	 */
	public void setDoubles(int doubles) {
		this.doubles = doubles;
	}
	
	/**
	 * Gets the homeruns.
	 *
	 * @return the homeruns
	 */
	public int getHomeruns() {
		return homeruns;
	}
	
	/**
	 * Sets the homeruns.
	 *
	 * @param homeruns the new homeruns
	 */
	public void setHomeruns(int homeruns) {
		this.homeruns = homeruns;
	}
	
	/**
	 * Gets the walks.
	 *
	 * @return the walks
	 */
	public int getWalks() {
		return walks;
	}
	
	/**
	 * Sets the walks.
	 *
	 * @param walks the new walks
	 */
	public void setWalks(int walks) {
		this.walks = walks;
	}
	
	/**
	 * Gets the strikeouts.
	 *
	 * @return the strikeouts
	 */
	public int getStrikeouts() {
		return strikeouts;
	}
	
	/**
	 * Sets the strikeouts.
	 *
	 * @param strikeouts the new strikeouts
	 */
	public void setStrikeouts(int strikeouts) {
		this.strikeouts = strikeouts;
	}


	/**
	 * Gets the team id.
	 *
	 * @return the team id
	 */
	public int getTeam_id() {
		return team_id;
	}


	/**
	 * Sets the team id.
	 *
	 * @param team_id the new team id
	 */
	public void setTeam_id(int team_id) {
		this.team_id = team_id;
	}


	/**
	 * Gets the runs.
	 *
	 * @return the runs
	 */
	public int getRuns() {
		return runs;
	}


	/**
	 * Sets the runs.
	 *
	 * @param runs the new runs
	 */
	public void setRuns(int runs) {
		this.runs = runs;
	}


	/**
	 * Gets the rbi.
	 *
	 * @return the rbi
	 */
	public int getRbi() {
		return rbi;
	}


	/**
	 * Sets the rbi.
	 *
	 * @param rbi the new rbi
	 */
	public void setRbi(int rbi) {
		this.rbi = rbi;
	}


	/**
	 * Gets the today stats.
	 *
	 * @return the today stats
	 */
	public Player getTodayStats() {
		return todayStats;
	}

	/**
	 * Sets the today stats.
	 *
	 * @param todayStats the new today stats
	 */
	public void setTodayStats(Player todayStats) {
		this.todayStats = todayStats;
	}

	
	
}
