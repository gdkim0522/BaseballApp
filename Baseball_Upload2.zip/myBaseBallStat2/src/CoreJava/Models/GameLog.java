package CoreJava.Models;


// TODO: Auto-generated Javadoc
/**
 * 
 * This is the Game Log class which holds all the relevant data for each game transaction. 
 * 
 * @author Greg Kim
 *
 */


//Tracks all instances of the game results.
public class GameLog {
	
	/** The playseries. */
	int playseries;
	
	/** The currentplay. */
	int currentplay;
	
	/** The date. */
	String date;
	
	/** The time. */
	String time; 
	
	/** The top. */
	boolean top;
	
	/** The score updated. */
	boolean score_updated;
	
	/** The inning. */
	int inning;

	/** The balls. */
	int balls;
	
	/** The strikes. */
	int strikes;
	
	/** The outs. */
	int outs;
	
	/** The visiting id. */
	int visiting_id;
	
	/** The home id. */
	int home_id;	
	
	/** The hitter id. */
	int hitter_id;
	
	/** The pitcher id. */
	int pitcher_id;
	
	/** The result. */
	String result;
	
	/** The on first. */
	Player onFirst;
	
	/** The on second. */
	Player onSecond;
	
	/** The on third. */
	Player onThird;
	
	/** The on home. */
	Player onHome;
	
	/** The hometeam runs. */
	int hometeam_runs;
	
	/** The visitingteam runs. */
	int visitingteam_runs;
	
	/** The hometeam hits. */
	int hometeam_hits;
	
	/** The visitingteam hits. */
	int visitingteam_hits;

	
	/**
	 * Instantiates a new game log.
	 */
	public GameLog() {
		
	}
	
	/**
	 * Instantiates a new game log.
	 *
	 * @param playlog the playlog
	 * @param currentplay the currentplay
	 * @param result the result
	 * @param inning the inning
	 * @param top the top
	 * @param balls the balls
	 * @param strikes the strikes
	 * @param outs the outs
	 * @param total_visitteam_runs the total visitteam runs
	 * @param total_hometeam_runs the total hometeam runs
	 * @param hitter_id the hitter id
	 * @param pitcher_id the pitcher id
	 * @param score_updated the score updated
	 */
	public GameLog(int playlog, Integer currentplay, String result, int inning, boolean top, int balls, int strikes, int outs,
			int total_visitteam_runs, int total_hometeam_runs,int hitter_id,int pitcher_id, boolean score_updated) {
		this.playseries=playlog;
		this.currentplay=currentplay;
		this.result=result;
		this.inning=inning;
		this.top=top;
		this.balls=balls;
		this.strikes=strikes;
		this.outs=outs;
		this.visitingteam_runs=total_visitteam_runs;
		this.hometeam_runs=total_hometeam_runs;
		this.hitter_id=hitter_id;
		this.pitcher_id=pitcher_id;
		this.score_updated=score_updated;
	}
	
	

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object object) {
		if(object instanceof GameLog) {
			GameLog other=(GameLog) object;
			boolean SamePlaySeries=(this.playseries==other.getPlayseries());
			boolean SameCurrentPlay=(this.currentplay==other.getCurrentplay());
			boolean SameResult=this.result.equals(other.getResult());
			boolean SameInning=(this.inning==other.getInning());
			boolean SameTop=(this.top==other.isTop());
			boolean SameBalls=(this.balls==other.getBalls());			
			boolean SameStrikes=(this.strikes==other.getStrikes());
			boolean SameOuts=(this.outs==other.getOuts());

			boolean SameVisitRuns=(this.visitingteam_runs==other.getVisitingteam_runs());			
			boolean SameHomeRuns=(this.hometeam_runs==other.getHometeam_runs());
			boolean SameHitterID=(this.hitter_id==other.getHitter_id());
			boolean SamePitcherID=(this.pitcher_id==other.getPitcher_id());
			boolean SameScoreUpdated=(this.score_updated==other.isScore_updated());
			
			
			
			if(SamePlaySeries && SameCurrentPlay && SameResult && SameInning && SameTop && SameBalls && 
					SameStrikes && SameOuts && SameVisitRuns && SameHomeRuns && SameHitterID && SamePitcherID && SameScoreUpdated)
				return true;
			else
				return false;
			
		}else
			return false;
	}	
	
	
	/**
	 * Gets the date.
	 *
	 * @return the date
	 */
	public String getDate() {
		return date;
	}
	
	/**
	 * Sets the date.
	 *
	 * @param date the new date
	 */
	public void setDate(String date) {
		this.date = date;
	}
	
	/**
	 * Gets the time.
	 *
	 * @return the time
	 */
	public String getTime() {
		return time;
	}
	
	/**
	 * Sets the time.
	 *
	 * @param time the new time
	 */
	public void setTime(String time) {
		this.time = time;
	}
	
	/**
	 * Gets the visiting id.
	 *
	 * @return the visiting id
	 */
	public int getVisiting_id() {
		return visiting_id;
	}
	
	/**
	 * Sets the visiting id.
	 *
	 * @param visiting_id the new visiting id
	 */
	public void setVisiting_id(int visiting_id) {
		this.visiting_id = visiting_id;
	}
	
	/**
	 * Gets the home id.
	 *
	 * @return the home id
	 */
	public int getHome_id() {
		return home_id;
	}
	
	/**
	 * Sets the home id.
	 *
	 * @param home_id the new home id
	 */
	public void setHome_id(int home_id) {
		this.home_id = home_id;
	}
	
	/**
	 * Checks if is top.
	 *
	 * @return true, if is top
	 */
	public boolean isTop() {
		return top;
	}
	
	/**
	 * Sets the top.
	 *
	 * @param top the new top
	 */
	public void setTop(boolean top) {
		this.top = top;
	}
	
	/**
	 * Gets the inning.
	 *
	 * @return the inning
	 */
	public int getInning() {
		return inning;
	}
	
	/**
	 * Sets the inning.
	 *
	 * @param inning the new inning
	 */
	public void setInning(int inning) {
		this.inning = inning;
	}
	
	/**
	 * Gets the balls.
	 *
	 * @return the balls
	 */
	public int getBalls() {
		return balls;
	}
	
	/**
	 * Sets the balls.
	 *
	 * @param balls the new balls
	 */
	public void setBalls(int balls) {
		this.balls = balls;
	}
	
	/**
	 * Gets the strikes.
	 *
	 * @return the strikes
	 */
	public int getStrikes() {
		return strikes;
	}
	
	/**
	 * Sets the strikes.
	 *
	 * @param strikes the new strikes
	 */
	public void setStrikes(int strikes) {
		this.strikes = strikes;
	}
	
	/**
	 * Gets the outs.
	 *
	 * @return the outs
	 */
	public int getOuts() {
		return outs;
	}
	
	/**
	 * Sets the outs.
	 *
	 * @param outs the new outs
	 */
	public void setOuts(int outs) {
		this.outs = outs;
	}

	/**
	 * Gets the pitcher id.
	 *
	 * @return the pitcher id
	 */
	public int getPitcher_id() {
		return pitcher_id;
	}
	
	/**
	 * Sets the pitcher id.
	 *
	 * @param pitcher_id the new pitcher id
	 */
	public void setPitcher_id(int pitcher_id) {
		this.pitcher_id = pitcher_id;
	}
	
	/**
	 * Gets the result.
	 *
	 * @return the result
	 */
	public String getResult() {
		return result;
	}
	
	/**
	 * Sets the result.
	 *
	 * @param result the new result
	 */
	public void setResult(String result) {
		this.result = result;
	}
	
	/**
	 * Gets the hometeam runs.
	 *
	 * @return the hometeam runs
	 */
	public int getHometeam_runs() {
		return hometeam_runs;
	}
	
	/**
	 * Sets the hometeam runs.
	 *
	 * @param hometeam_runs the new hometeam runs
	 */
	public void setHometeam_runs(int hometeam_runs) {
		this.hometeam_runs = hometeam_runs;
	}
	
	/**
	 * Gets the visitingteam runs.
	 *
	 * @return the visitingteam runs
	 */
	public int getVisitingteam_runs() {
		return visitingteam_runs;
	}
	
	/**
	 * Sets the visitingteam runs.
	 *
	 * @param visitingteam_runs the new visitingteam runs
	 */
	public void setVisitingteam_runs(int visitingteam_runs) {
		this.visitingteam_runs = visitingteam_runs;
	}
	
	/**
	 * Gets the hometeam hits.
	 *
	 * @return the hometeam hits
	 */
	public int getHometeam_hits() {
		return hometeam_hits;
	}
	
	/**
	 * Sets the hometeam hits.
	 *
	 * @param hometeam_hits the new hometeam hits
	 */
	public void setHometeam_hits(int hometeam_hits) {
		this.hometeam_hits = hometeam_hits;
	}
	
	/**
	 * Gets the visitingteam hits.
	 *
	 * @return the visitingteam hits
	 */
	public int getVisitingteam_hits() {
		return visitingteam_hits;
	}
	
	/**
	 * Sets the visitingteam hits.
	 *
	 * @param visitingteam_hits the new visitingteam hits
	 */
	public void setVisitingteam_hits(int visitingteam_hits) {
		this.visitingteam_hits = visitingteam_hits;
	}
	
	/**
	 * Gets the playseries.
	 *
	 * @return the playseries
	 */
	public int getPlayseries() {
		return playseries;
	}
	
	/**
	 * Sets the playseries.
	 *
	 * @param playseries the new playseries
	 */
	public void setPlayseries(int playseries) {
		this.playseries = playseries;
	}
	
	/**
	 * Gets the on first.
	 *
	 * @return the on first
	 */
	public Player getOnFirst() {
		return onFirst;
	}
	
	/**
	 * Sets the on first.
	 *
	 * @param onFirst the new on first
	 */
	public void setOnFirst(Player onFirst) {
		this.onFirst = onFirst;
	}
	
	/**
	 * Gets the on second.
	 *
	 * @return the on second
	 */
	public Player getOnSecond() {
		return onSecond;
	}
	
	/**
	 * Sets the on second.
	 *
	 * @param onSecond the new on second
	 */
	public void setOnSecond(Player onSecond) {
		this.onSecond = onSecond;
	}
	
	/**
	 * Gets the on third.
	 *
	 * @return the on third
	 */
	public Player getOnThird() {
		return onThird;
	}
	
	/**
	 * Sets the on third.
	 *
	 * @param onThird the new on third
	 */
	public void setOnThird(Player onThird) {
		this.onThird = onThird;
	}
	
	/**
	 * Gets the on home.
	 *
	 * @return the on home
	 */
	public Player getOnHome() {
		return onHome;
	}
	
	/**
	 * Sets the on home.
	 *
	 * @param onHome the new on home
	 */
	public void setOnHome(Player onHome) {
		this.onHome = onHome;
	}

	/**
	 * Gets the currentplay.
	 *
	 * @return the currentplay
	 */
	public int getCurrentplay() {
		return currentplay;
	}

	/**
	 * Sets the currentplay.
	 *
	 * @param currentplay the new currentplay
	 */
	public void setCurrentplay(int currentplay) {
		this.currentplay = currentplay;
	}

	/**
	 * Gets the hitter id.
	 *
	 * @return the hitter id
	 */
	public int getHitter_id() {
		return hitter_id;
	}

	/**
	 * Sets the hitter id.
	 *
	 * @param hitter_id the new hitter id
	 */
	public void setHitter_id(int hitter_id) {
		this.hitter_id = hitter_id;
	}

	/**
	 * Checks if is score updated.
	 *
	 * @return true, if is score updated
	 */
	public boolean isScore_updated() {
		return score_updated;
	}

	/**
	 * Sets the score updated.
	 *
	 * @param score_updated the new score updated
	 */
	public void setScore_updated(boolean score_updated) {
		this.score_updated = score_updated;
	}
	
	

}
