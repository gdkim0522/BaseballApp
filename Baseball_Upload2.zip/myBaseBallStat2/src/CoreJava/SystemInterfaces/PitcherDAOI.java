package CoreJava.SystemInterfaces;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import CoreJava.Models.Pitcher;

// TODO: Auto-generated Javadoc
/**
 * The Interface PitcherDAOI.
 */
public interface PitcherDAOI {
	
	/**
	 * The Enum SQL.
	 */
	enum SQL{
		
		/** The get pitcher by id. */
		GET_PITCHER_BY_ID("select * from pitcher where team_id=? and player_id=?"),
		
		/** The get pitchers by teamid. */
		GET_PITCHERS_BY_TEAMID("select * from pitcher where team_id=?");
		
		/** The query. */
		private final String query;
		
		/**
		 * Instantiates a new sql.
		 *
		 * @param query the query
		 */
		private SQL(String query) {
			this.query=query;
		}
		
		/**
		 * Gets the query.
		 *
		 * @return the query
		 */
		public String getQuery() {
			return this.query;
		}
	}
	
	/**
	 * Gets the pitcher by ID.
	 *
	 * @param team_id the team id
	 * @param player_id the player id
	 * @return the pitcher by ID
	 * @throws SQLException the SQL exception
	 * @throws ClassNotFoundException the class not found exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	Pitcher getPitcherByID(int team_id, int player_id) throws SQLException, ClassNotFoundException, IOException;
	
	/**
	 * Gets the pitcher by team ID.
	 *
	 * @param team_id the team id
	 * @return the pitcher by team ID
	 * @throws ClassNotFoundException the class not found exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws SQLException the SQL exception
	 */
	List<Pitcher> getPitcherByTeamID(int team_id) throws ClassNotFoundException, IOException, SQLException;
}
