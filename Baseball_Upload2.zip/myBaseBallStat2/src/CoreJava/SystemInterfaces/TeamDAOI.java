package CoreJava.SystemInterfaces;

import java.sql.SQLException;
import java.util.List;

import CoreJava.Models.Team;

// TODO: Auto-generated Javadoc
/**
 * The Interface TeamDAOI.
 */
public interface TeamDAOI {
	
	/**
	 * The Enum SQL.
	 */
	enum SQL{
		
		/** The get team by id. */
		GET_TEAM_BY_ID("Select * from team where team_id=?"),
		
		/** The get all teams. */
		GET_ALL_TEAMS("Select * from team"),
		
		/** The get team standings. */
		GET_TEAM_STANDINGS("select * from team order by wins desc"),
		
		/** The update team wins. */
		UPDATE_TEAM_WINS("update team set wins=wins+1 where team_id=?"),
		
		/** The update team losses. */
		UPDATE_TEAM_LOSSES("update team set losses=losses+1 where team_id=?");
		
		
		
		/** The query. */
		private final String query;
		
		/**
		 * Instantiates a new sql.
		 *
		 * @param s the s
		 */
		private SQL(String s) {
			this.query=s;
		}
		
		/**
		 * Gets the query.
		 *
		 * @return the query
		 */
		public String getQuery() {
			return this.query;
		}
	}
	
	/**
	 * Gets the team by id.
	 *
	 * @param team_id the team id
	 * @return the team by id
	 * @throws SQLException the SQL exception
	 * @throws ClassNotFoundException the class not found exception
	 */
	public Team getTeamById(int team_id) throws SQLException, ClassNotFoundException;
	
	/**
	 * Gets the all teams.
	 *
	 * @return the all teams
	 * @throws SQLException the SQL exception
	 * @throws ClassNotFoundException the class not found exception
	 */
	public List<Team> getAllTeams() throws SQLException, ClassNotFoundException;
	
	/**
	 * Gets the team standings.
	 *
	 * @return the team standings
	 * @throws SQLException the SQL exception
	 * @throws ClassNotFoundException the class not found exception
	 */
	public List<Team> getTeamStandings() throws SQLException, ClassNotFoundException;
	
	/**
	 * Update team wins.
	 *
	 * @param team_id the team id
	 * @return the int
	 * @throws SQLException the SQL exception
	 * @throws ClassNotFoundException the class not found exception
	 */
	public int updateTeamWins(int team_id) throws SQLException, ClassNotFoundException;
	
	/**
	 * Update team losses.
	 *
	 * @param team_id the team id
	 * @return the int
	 * @throws SQLException the SQL exception
	 * @throws ClassNotFoundException the class not found exception
	 */
	public int updateTeamLosses(int team_id) throws SQLException, ClassNotFoundException;
	
}
