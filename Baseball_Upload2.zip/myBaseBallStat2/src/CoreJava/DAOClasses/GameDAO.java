package CoreJava.DAOClasses;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import CoreJava.Models.GameLog;
import CoreJava.SystemInterfaces.GameDAOI;

// TODO: Auto-generated Javadoc
/**
 * The Class GameDAO.
 *
 * @author Greg Kim
 * 
 *  <div>
 *  Class used to log each game transaction play into a table .
 *  </div>
 */
public class GameDAO extends AbstractDAO implements GameDAOI{
	
	/** The method. */
	String method="GameDAO - ";

	
	/* (non-Javadoc)
	 * @see CoreJava.SystemInterfaces.GameDAOI#addGameLog(int, int, java.lang.String, int, boolean, int, int, int, int, int, int, int, boolean)
	 */
	@Override
	public int addGameLog(int playlog, int current_play, String result_outcome, int inning, boolean top, int balls, int strikes,
			int outs, int visit_runs, int home_runs, int hitter_id, int pitcher_id, boolean score_updated)
			throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		method="GameDAO - ";
		method=method.concat("addGameLog() - ");				
		int result=0;
		
		try
		{ 
			//Assign course_id and student_id
			connect();
			
			//sql="INSERT INTO ATTENDING(course_id, student_id) VALUES(?,?)";
			
			ps=conn.prepareStatement(SQL.ADD_GAMELOG.getQuery());
			
			String top_string="false";
			String score_updated_string="false";
			
			
			if(top)
				top_string="true";
			
			if(score_updated)
				score_updated_string="true";
			

  			//Run Insert
  			ps.setInt(1, playlog);
  			ps.setInt(2, current_play);
  			ps.setString(3, result_outcome);
  			ps.setInt(4, inning);
  			ps.setString(5, top_string);
  			ps.setInt(6, balls);
  			ps.setInt(7, strikes);
  			ps.setInt(8, outs);
  			ps.setInt(9, visit_runs);  			
  			ps.setInt(10, home_runs);
  			ps.setInt(11, hitter_id);
  			ps.setInt(12, pitcher_id);
  			ps.setString(13, score_updated_string);  			
  			
  			result= ps.executeUpdate();
  			if(result==1)
  				return 1;
  			else
  				return -100;
        } catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(method +EXSQL + e.getMessage());
		}catch(Exception ex) { 
			System.out.println(method +EX + ex.getMessage()); 
		}finally {
         dispose();
      } 
		
		return -100;
	}

	/* (non-Javadoc)
	 * @see CoreJava.SystemInterfaces.GameDAOI#getGameLogScore(java.lang.String)
	 */
	@Override
	public List<GameLog> getGameLogScore(String scoreupdated) throws ClassNotFoundException, IOException, SQLException {
		// TODO Auto-generated method stub
		List<GameLog> gameLog_Score=new LinkedList<GameLog>();
		method="GameDAO - ";
		method=method.concat("getGameLogScore() - ");				
		
		try
		{ 
		  connect();
		  ps = conn.prepareStatement(SQL.GET_GAMELOG_SCORE.getQuery());  
		  ps.setString(1, scoreupdated);
		  rs=ps.executeQuery();

		  //rs.next();
		  while(rs.next()) {
    		
			boolean top=false;
			boolean score_updated=false;
			
			if(rs.getString(5).equals("true"))
				top=true;
			
			if(rs.getString(13).equals("true"))
				score_updated=true;			
			  
    		
    		gameLog_Score.add(new GameLog(rs.getInt(1),rs.getInt(2), rs.getString(3),rs.getInt(4),top,rs.getInt(6),rs.getInt(7),rs.getInt(8),rs.getInt(9),
    				rs.getInt(10),rs.getInt(11),rs.getInt(12),score_updated));

    		
		  }
		  
		  return gameLog_Score;
		  
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(method +EXSQL + e.getMessage());
		}catch(Exception ex) { 
			System.out.println(method +EX + ex.getMessage()); 
		}finally {
			dispose();
		}
		return null;		
	}

	/* (non-Javadoc)
	 * @see CoreJava.SystemInterfaces.GameDAOI#getGameLogCurrent(int, int)
	 */
	@Override
	public List<GameLog> getGameLogCurrent(int hitter_id, int play_series) throws ClassNotFoundException, IOException, SQLException {
		// TODO Auto-generated method stub
		List<GameLog> gameLog_Current=new LinkedList<GameLog>();
		method="GameDAO - ";
		method=method.concat("getGameLogCurrent() - ");				
		
		gameLog_Current.clear();
		
		try
		{ 
		  connect();
		  ps = conn.prepareStatement(SQL.GET_GAMELOG_CURRENT.getQuery());  
		  ps.setInt(1, hitter_id);
		  ps.setInt(2, play_series);
		  rs=ps.executeQuery();

		  //rs.next();
		  while(rs.next()) {
    		
			boolean top=false;
			boolean score_updated=false;
			
			if(rs.getString(5).equals("true"))
				top=true;
			
			if(rs.getString(13).equals("true"))
				score_updated=true;			
			  
    		
			gameLog_Current.add(new GameLog(rs.getInt(1),rs.getInt(2), rs.getString(3),rs.getInt(4),top,rs.getInt(6),rs.getInt(7),rs.getInt(8),rs.getInt(9),
    				rs.getInt(10),rs.getInt(11),rs.getInt(12),score_updated));

		  }
		  
		  return gameLog_Current;
		  
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(method +EXSQL + e.getMessage());
		}catch(Exception ex) { 
			System.out.println(method +EX + ex.getMessage()); 
		}finally {
			dispose();
		}
		return null;	
	}

	/* (non-Javadoc)
	 * @see CoreJava.SystemInterfaces.GameDAOI#truncateGameLog()
	 */
	@Override
	public int truncateGameLog() throws ClassNotFoundException, IOException, SQLException {
		// TODO Auto-generated method stub
		method="GameDAO - ";
		method=method.concat("truncateGameLog() - ");				
		int result=0;
		
		try
		{ 
			//Assign course_id and student_id
			connect();
			
			//sql="INSERT INTO ATTENDING(course_id, student_id) VALUES(?,?)";
			
			ps=conn.prepareStatement(SQL.TRUNCATE_TABLE_GAMELOG.getQuery());
			
  			result= ps.executeUpdate();
  			if(result==1)
  				return 1;
  			else
  				return -100;
        } catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(method +EXSQL + e.getMessage());
		}catch(Exception ex) { 
			System.out.println(method +EX + ex.getMessage()); 
		}finally {
         dispose();
      } 
		
		return -100;
	}

	/* (non-Javadoc)
	 * @see CoreJava.SystemInterfaces.GameDAOI#getGameLogCurrentHitter(int)
	 */
	@Override
	public List<GameLog> getGameLogCurrentHitter(int hitter_id)
			throws ClassNotFoundException, IOException, SQLException {
		// TODO Auto-generated method stub
		List<GameLog> gameLog_Current=new LinkedList<GameLog>();
		method="GameDAO - ";
		method=method.concat("getGameLogCurrentHitter() - ");				
		
		gameLog_Current.clear();
		
		try
		{ 
		  connect();
		  ps = conn.prepareStatement(SQL.GET_GAMELOG_CURRENTHITTER.getQuery());  
		  ps.setInt(1, hitter_id);
		  rs=ps.executeQuery();

		  //rs.next();
		  while(rs.next()) {
    		
			boolean top=false;
			boolean score_updated=false;
			
			if(rs.getString(5).equals("true"))
				top=true;
			
			if(rs.getString(13).equals("true"))
				score_updated=true;			
			  
    		
			gameLog_Current.add(new GameLog(rs.getInt(1),rs.getInt(2), rs.getString(3),rs.getInt(4),top,rs.getInt(6),rs.getInt(7),rs.getInt(8),rs.getInt(9),
    				rs.getInt(10),rs.getInt(11),rs.getInt(12),score_updated));

		  }
		  
		  return gameLog_Current;
		  
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(method +EXSQL + e.getMessage());
		}catch(Exception ex) { 
			System.out.println(method +EX + ex.getMessage()); 
		}finally {
			dispose();
		}
		return null;	
	}


//	
//	
//	int registerAttending(int student_id, int course_id) throws SQLException, ClassNotFoundException {
//		method="AttendingDAO - ";
//		method=method.concat("registerAttending() - ");				
//		int result=0;
//		
//		try
//		{ 
//			//Assign course_id and student_id
//			connect();
//			
//			//sql="INSERT INTO ATTENDING(course_id, student_id) VALUES(?,?)";
//			
//			ps=conn.prepareStatement(SQL.REGISTER_STUDENT_TO_COURSE.getQuery());
//
//  			//Run Insert
//  			ps.setInt(2, student_id);
//  			ps.setInt(1, course_id);
//  			result= ps.executeUpdate();
//  			if(result==1)
//  				return getMaxID();
//  			else
//  				return -100;
//        } catch (ClassNotFoundException e) {
//			// TODO Auto-generated catch block
//			System.out.println(method +EXCLASS + e.getMessage());
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			System.out.println(method +EXSQL + e.getMessage());
//		}catch(Exception ex) { 
//			System.out.println(method +EX + ex.getMessage()); 
//		}finally {
//         dispose();
//      } 
//		
//		return -100;
//	}
//	
//	//JDBC Driver to connect to Database to run SQL Statements.
//	public int getMaxID() throws ClassNotFoundException, SQLException {
//		method="AttendingDAO - ";
//		method=method.concat("getMaxID() - ");				
//		try
//		{
//          //Reference to connection interface
//		  connect();
//
//          sql="Select max(attending_id) from attending";       
//          st = conn.createStatement();  
//          rs=st.executeQuery(sql);  
//          
//          if(rs!=null) {          
//	          rs.next();
//	          int id=rs.getInt(1);
//	          
//	          return id;
//          }
//          
//          //step5 close the connection object  
//          System.out.println("RS is NULL!!!!");
//        }catch (SQLException e) {
//			// TODO Auto-generated catch block
//			System.out.println(method +EXSQL + e.getMessage());
//		}catch(Exception ex) { 
//			System.out.println(method +EX + ex.getMessage()); 
//		}finally {
//          dispose();
//          
//      }  	
//		return -100;
//	}

			
}
