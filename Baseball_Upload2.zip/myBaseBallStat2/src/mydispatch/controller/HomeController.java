package mydispatch.controller;

import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.aspectj.weaver.ast.Test;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import CoreJava.Models.User;
import CoreJava.DAOClasses.UserDAO;
import CoreJava.Models.Game;
import CoreJava.Models.GameLog;
import CoreJava.Models.Hitter;
import CoreJava.Models.Pitcher;


// TODO: Auto-generated Javadoc
/**
 * The Class HomeController.
 *
 * @author Greg Kim
 * 
 * Home Controller
 * This is the controller used for the index , registration, and selection page.
 */

@Controller
@RequestMapping("/")
@SessionAttributes("user")
public class HomeController {
		
		/**
		 * Index page.
		 *
		 * @return the model and view
		 */
		@RequestMapping("/")
		public ModelAndView indexPage() {
			System.out.println("This is index");
			
			getData();

			ModelAndView mav=new ModelAndView("index");
			
			return mav;
		}
		

		/**
		 * Based on user selection, user picks the pitchers.
		 *
		 * @param user the user
		 * @param pRequest the request
		 * @return the model and view
		 */
		
		@RequestMapping(value= {"/selectionpage"},method=RequestMethod.POST)
		public ModelAndView selectionpitcherPage(@ModelAttribute("user") User user,HttpServletRequest pRequest) {
			ModelAndView mav=new ModelAndView("selectionpage");
			
			String visit_id=pRequest.getParameter("visit_team");
			String home_id=pRequest.getParameter("home_team");
			String team_id=pRequest.getParameter("teamId");
			
			int visitid=Integer.parseInt(visit_id);
			int homeid=Integer.parseInt(home_id);
			
			HttpSession session=pRequest.getSession();		
			Game ballgame=(Game) session.getAttribute("ballgame");
			

			try {
				//Game ballgame=new Game();

				mav.addObject("visit_id", visit_id);
				mav.addObject("home_id", home_id);
				
				ballgame.getPitcherDAO(visitid,homeid);
				
				System.out.println("vis_id" + visit_id);
				System.out.println("home_id" + home_id);
				

				mav.addObject("vis_pitchers", ballgame.getVisit_Pitchers());
				mav.addObject("hom_pitchers", ballgame.getHome_Pitchers());
				mav.addObject("team_id", 1);
				mav.addObject("visit_id", visit_id);
				mav.addObject("home_id", home_id);
				mav.addObject("visit_team", ballgame.getVisit_team());
				mav.addObject("home_team", ballgame.getHome_team());
				
//				ballgame.assignHittersDAO(visitid, homeid, 1, 3);
//				Pitcher home_pitcher=ballgame.getCurrent_HomePitcher();
//				Pitcher visit_pitcher=ballgame.getCurrent_VisitPitcher();
				
//				float vp_era=(visit_pitcher.getRuns()*9)/visit_pitcher.getInnings();
//				float hp_era=(home_pitcher.getRuns()*9)/home_pitcher.getInnings();
//				
//				DecimalFormat df = new DecimalFormat("#.00");
//				String visit_era = df.format(vp_era);
//				String home_era = df.format(hp_era);
				
				
//				mav.addObject("visit_era", visit_era);
//				mav.addObject("home_era", home_era);
//				mav.addObject("team_id", team_id);
//				
//
//				mav.addObject("visit_team", ballgame.getVisit_Hitters());
//				mav.addObject("home_team", ballgame.getHome_Hitters());
//				
//				
//				mav.addObject("visit_pitcher", visit_pitcher);
//				mav.addObject("home_pitcher", home_pitcher);
				
//				HttpSession session=pRequest.getSession();
				
				session.setAttribute("ballgame", ballgame);
				
				return mav;
				
			} catch (Exception e) {
//				System.out.println(e.getStackTrace());
				e.printStackTrace();
				//System.out.println("EX Error at selectionPage " + e.getMessage());
			}

			
			return mav;
		}		
		
		/**
		 * Show current lineup based on pitcherids and teamids.
		 *
		 * @param user the user
		 * @param pRequest the request
		 * @return the model and view
		 */
		
		
		@RequestMapping(value= {"/show_lineup"},method=RequestMethod.POST)
		public ModelAndView selectionTeamPage(@ModelAttribute("user") User user,HttpServletRequest pRequest) {
			ModelAndView mav=new ModelAndView("selectionpage");
			
			String visit_id=pRequest.getParameter("visitId");
			String home_id=pRequest.getParameter("homeId");
			String visit_pitcher_id=pRequest.getParameter("visitPitcherId");
			String home_pitcher_id=pRequest.getParameter("homePitcherId");
			String team_id=pRequest.getParameter("teamId");
			
			int visitid=Integer.parseInt(visit_id);
			int homeid=Integer.parseInt(home_id);
			int visitpitcherid=Integer.parseInt(visit_pitcher_id);
			int homepitcherid=Integer.parseInt(home_pitcher_id);
			
			HttpSession session=pRequest.getSession();		
			Game ballgame=(Game) session.getAttribute("ballgame");
//		
//			
//			//Course course=new Course();
//			
			try {
				//Game ballgame=new Game();

				mav.addObject("visit_id", visit_id);
				mav.addObject("home_id", home_id);
				
//				ballgame.getPitcherDAO(visitid,homeid);
//
//				mav.addObject("v_pitchers", ballgame.getVisit_Pitchers());
//				mav.addObject("h_pitchers", ballgame.getHome_Pitchers());
				
				
				ballgame.assignHittersDAO(visitid, homeid, visitpitcherid, homepitcherid);
				Pitcher home_pitcher=ballgame.getCurrent_HomePitcher();
				Pitcher visit_pitcher=ballgame.getCurrent_VisitPitcher();
				
				float vp_era=(visit_pitcher.getRuns()*9)/visit_pitcher.getInnings();
				float hp_era=(home_pitcher.getRuns()*9)/home_pitcher.getInnings();
//				
				DecimalFormat df = new DecimalFormat("#.00");
				String visit_era = df.format(vp_era);
				String home_era = df.format(hp_era);
				
				
				mav.addObject("visit_era", visit_era);
				mav.addObject("home_era", home_era);
				mav.addObject("visit_pitcher", visit_pitcher);
				mav.addObject("home_pitcher", home_pitcher);
				
				
				mav.addObject("team_id", team_id);

				mav.addObject("visit_team", ballgame.getVisit_team());
				mav.addObject("home_team", ballgame.getHome_team());
				mav.addObject("visit_team_hitters", ballgame.getVisit_Hitters());
				mav.addObject("home_team_hitters", ballgame.getHome_Hitters());				

				
				mav.addObject("team_id", 2);
				
				//HttpSession session=pRequest.getSession();
				
				session.setAttribute("ballgame", ballgame);
				
			} catch (Exception e) {
//				System.out.println(e.getStackTrace());
				e.printStackTrace();
				//System.out.println("EX Error at selectionPage " + e.getMessage());
			}

			
			return mav;
		}		
		
		
		
		
		/**
		 * Tracker page.
		 *
		 * @param v_pitcher the v pitcher
		 * @param pRequest the request
		 * @return the model and view
		 */
		@RequestMapping("/Baseball_Tracker")
		public ModelAndView trackerPage(@ModelAttribute("visit_pitcher") Pitcher v_pitcher,HttpServletRequest pRequest) {
			
			ModelAndView mav=new ModelAndView("tracker");
			
			HttpSession session=pRequest.getSession();		
			Game ballgame=(Game) session.getAttribute("ballgame");
			
			ballgame.getGameMenu();
			
			Pitcher home_pitcher=ballgame.getCurrent_HomePitcher();
			Pitcher visit_pitcher=ballgame.getCurrent_VisitPitcher();
			Hitter current_hitter=ballgame.getCurrent_Hitter();
			
			float vp_era=(visit_pitcher.getRuns()*9)/visit_pitcher.getInnings();
			float hp_era=(home_pitcher.getRuns()*9)/home_pitcher.getInnings();
			
			DecimalFormat df = new DecimalFormat("#.00");
			String visit_era = df.format(vp_era);
			String home_era = df.format(hp_era);
			
			Pitcher current_pitcher=ballgame.getCurrent_Pitcher();
			
			mav.addObject("current_hitter", current_hitter);
			mav.addObject("current_pitcher", current_pitcher);
			mav.addObject("balls", ballgame.getBalls());
			mav.addObject("strikes", ballgame.getStrikes());
			mav.addObject("outs", ballgame.getOuts());
			mav.addObject("inning", ballgame.getInning());
			mav.addObject("top", (ballgame.isTop())?"Top":"Bottom");	
			mav.addObject("visit_runs", ballgame.getTotal_visitteam_runs());
			mav.addObject("home_runs", ballgame.getTotal_hometeam_runs());
			
			Map<Integer, Hitter> OnBase=ballgame.getOnBase();
			
			for(int i=1;i<=OnBase.size();i++) {
				if(OnBase.get(i)!=null) {
					Hitter runner=OnBase.get(i);
					mav.addObject("Runner_" + i, runner.getFullName());
					//System.out.print(runner.getFullName() + " is on " + i + ". ");
				}
			}
			
			
			

			mav.addObject("visit_era", visit_era);
			mav.addObject("home_era", home_era);
			mav.addObject("visit_pitcher", visit_pitcher);
			mav.addObject("home_pitcher", home_pitcher);

			
			mav.addObject("visit_team", ballgame.getVisit_team());
			mav.addObject("home_team", ballgame.getHome_team());
			mav.addObject("visit_team_hitters", ballgame.getVisit_Hitters());
			mav.addObject("home_team_hitters", ballgame.getHome_Hitters());	
			
			mav.addObject("current_hitter", current_hitter);
			
			session.setAttribute("ballgame", ballgame);
			session.setAttribute("advance_runner", false);
			
			return mav;
		}
		
//		@RequestMapping(value= {"/tracker"},method=RequestMethod.POST)
//		public ModelAndView trackerPagePost(@ModelAttribute("visit_pitcher") Pitcher v_pitcher, HttpServletRequest pRequest,
//				@RequestParam("inputId") int result, @RequestParam("runnerId") int move_runner) {
//			
//			ModelAndView mav=new ModelAndView("Baseball_Tracker");
//			
//			//Get session ballgame object
//			HttpSession session=pRequest.getSession();		
//			Game ballgame=(Game) session.getAttribute("ballgame");
//			boolean advance_runner=(boolean) session.getAttribute("advance_runner");
//			
//			
//			
//			System.out.println("RESULT------ " + result);
//			
//			//Get variable
//			Pitcher home_pitcher=ballgame.getCurrent_HomePitcher();
//			Pitcher visit_pitcher=ballgame.getCurrent_VisitPitcher();
//			Hitter current_hitter=ballgame.getCurrent_Hitter();
//			
//			float vp_era=(visit_pitcher.getRuns()*9)/visit_pitcher.getInnings();
//			float hp_era=(home_pitcher.getRuns()*9)/home_pitcher.getInnings();
//			
//			DecimalFormat df = new DecimalFormat("#.00");
//			String visit_era = df.format(vp_era);
//			String home_era = df.format(hp_era);
//			
//			
//			//Add objects to mav
//			mav.addObject("visit_era", visit_era);
//			mav.addObject("home_era", home_era);
//			mav.addObject("visit_pitcher", visit_pitcher);
//			mav.addObject("home_pitcher", home_pitcher);
//			mav.addObject("current_hitter", current_hitter);
//			
//			String baseSituation="";
//
//			
//			
//			//Record transactions
//			
//			//Move runners
//			if(advance_runner) {
//				//If there are runner on base, advance them
//				mav.addObject("MoveRunner",1);
//				
//				ballgame.setBaseSituations(result);
//				
//				//baseSituation=ballgame.isBasesEmpty()
//				
//				
//				mav.addObject("base_situation",baseSituation);
//			
//			//Perform regular transactions
//			}else {
//				ballgame.recordTransaction(result);
//				
//				//If there are runner on base, advance them
//				if(true) {		
//					
//					if(!ballgame.isBasesEmpty()) {
//						mav.addObject("MoveRunner",1);
//						mav.addObject("base_situation",baseSituation);
//					}
//					
//				}else {
//					//If there are no runners, go to next transaction
//					mav.addObject("MoveRunner",0);
//				}
//			}
			
			
			
			
			
			
			
			
			
//			ballgame.getGameMenu();
//			
//			if(result<=0 || result>=10) {
////				if(result==10)
////					break;
//				mav.addObject("invalid", "Invalid Data");
//				//continue;
//			}else {
//				//Record transaction and Make New Decision based on input from scanner
//				ballgame.recordTransaction(result);
//			}
//			
//			//Check if game is over
//			if(ballgame.checkifGameOver()) {
//				mav.addObject("Game_Over", "Game is over");
//				
//			}
//			
//			
//			
//			
//			
//			
//			//Set Session Attribute
//			session.setAttribute("ballgame", ballgame);
//			
//			return mav;
//		}
		

		
		/**
 * Indexre page.
 *
 * @return the model and view
 */
@RequestMapping("/index")
		public ModelAndView indexrePage() {
			ModelAndView mav=new ModelAndView("index");
			
			return mav;
		}
		
		/**
		 * Register user page.
		 *
		 * @return the model and view
		 */
		@RequestMapping("/register_user")
		public ModelAndView register_userPage() {
			ModelAndView mav=new ModelAndView("register_user");
			
			return mav;
		}
		
		/**
		 * Logout.
		 *
		 * @return the model and view
		 */
		@RequestMapping("/logout")
		public ModelAndView logout() {
			ModelAndView mav=new ModelAndView("logout");
			
			return mav;
		}
		
		/**
		 * Sets the up user form.
		 *
		 * @return the user
		 */
		@ModelAttribute("user")
		public User setUpUserForm() {
			return new User();
		}
		
		
		/**
		 * Login page.
		 *
		 * @param user the user
		 * @param pRequest the request
		 * @param userName the user name
		 * @param password the password
		 * @return the model and view
		 */
		@RequestMapping(value="/login",method=RequestMethod.POST)
		ModelAndView loginPage(@ModelAttribute("user") User user,HttpServletRequest pRequest,
				@RequestParam("userName") String userName, @RequestParam("password") String password) {
			
			UserDAO userDAO=new UserDAO();
			User user_login=null;
			
			try {
				
				user_login=userDAO.validateUser(userName, password);
				
				if(user_login==null) {
					ModelAndView mav=new ModelAndView("index");
					mav.addObject("message", "Invalid Login");
					return mav;
				}else {
					
					
					System.out.println("This is selection page");
					
					Game ballgame=new Game();
		
					ModelAndView mav=new ModelAndView("selectionpage");
					mav.addObject("all_team", ballgame.getAll_teams());
					
					HttpSession session=pRequest.getSession();
					
					session.setAttribute("ballgame", ballgame);
					session.setAttribute("user", user);

					return mav;
				}
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Error at login " + e.getMessage());
			}
			
			System.out.println(userName);
			System.out.println(password);
			
			return null;
			
		}
		
		/**
		 * Process form page.
		 *
		 * @param user the user
		 * @param errors the errors
		 * @return the model and view
		 */
		@RequestMapping(value="/process-form",method=RequestMethod.POST)
		ModelAndView processFormPage(@ModelAttribute("user") @Valid User user,
				BindingResult errors) {
			
			try {
				
				if(errors.hasErrors()) {
					ModelAndView mav=new ModelAndView("register_user");
					return mav;
				}
				
				System.out.println(user.getFirstName());
				System.out.println(user.getPassword());

				
				UserDAO userDAO=new UserDAO();
				int result=userDAO.addUser(user.getFirstName(), user.getLastName(), user.getUserName(), user.getPassword());
				
				if(result==1) {
					System.out.println("Registration successful");
					
					ModelAndView mav=new ModelAndView("register_success");
					return mav;
				}else {
					System.out.println("Registration unsuccessful");					
					
					ModelAndView mav=new ModelAndView("register_error");
					return mav;
				}
//				
//				return mav;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("Error at Process Form Page: " + e.getMessage());
			}
			return null;
		}
		
		/**
		 * Gets the data.
		 *
		 * @return the data
		 */
		public void getData() {
			for(int i=0;i<10;++i)
				System.out.println("Test: " + i);
		}
}
