package mydispatch.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import CoreJava.DAOClasses.HitterDAO;
import CoreJava.Models.Game;
import CoreJava.Models.GameLog;
import CoreJava.Models.Hitter;
import CoreJava.Models.Pitcher;
import CoreJava.Models.Team;
import CoreJava.Models.User;


// TODO: Auto-generated Javadoc
/**
 * The Class TrackerController.
 *
 * @author Greg Kim
 * 
 * Home Controller
 * This is the controller used for the tracker and results page.
 */



@Controller
@RequestMapping("/")
public class TrackerController {
	
	/** The base situation. */
	String base_situation;
	
	
	
	/**
	 * Selection index page.
	 *
	 * @param pRequest the request
	 * @return the model and view
	 */
	@RequestMapping("/selectionpage")
	public ModelAndView selectionIndexPage(HttpServletRequest pRequest) {
		
		HttpSession session=pRequest.getSession();
		session.setAttribute("user", null);
		
		System.out.println("This is selectionpage");

		ModelAndView mav=new ModelAndView("selectionpage");
		
		return mav;
	}
	
	
	/**
	 * Tracker index page.
	 *
	 * @param pRequest the request
	 * @return the model and view
	 */
	@RequestMapping("/tracker")
	public ModelAndView trackerIndexPage(HttpServletRequest pRequest) {
		
		HttpSession session=pRequest.getSession();
		session.setAttribute("user", null);
		
		System.out.println("This is tracker");

		ModelAndView mav=new ModelAndView("tracker");
		
		return mav;
	}
	
	
	

	/**
	 * Handler to gather user input.
	 *
	 * @param user the user
	 * @param pRequest the request
	 * @param pResponse the response
	 * @param result the result
	 * @param move_to the move to
	 * @return the model and view
	 */
	
	
	@RequestMapping(value= {"/input_value"},method=RequestMethod.POST)
	public ModelAndView inputPost(@ModelAttribute("user") User user,HttpServletRequest pRequest, HttpServletResponse pResponse,
			@RequestParam("inputId") String result, @RequestParam("runnerId") String move_to) {
		
		try {
			

			HttpSession session=pRequest.getSession();
			Game ballgame=(Game) session.getAttribute("ballgame");
						
			ModelAndView mav=new ModelAndView("tracker");
			
			int v_result=Integer.parseInt(result);
			int v_move_to=Integer.parseInt(move_to);

			
			System.out.println("Test Result: " + v_result);		
			System.out.println("Move_to: " + v_move_to);	
			
			Hitter current_hitter=ballgame.getCurrent_Hitter();
			Pitcher current_pitcher=ballgame.getCurrent_Pitcher();
			
			Map<Integer, Hitter> OnBase=ballgame.getOnBase();
																		


			
			if(v_result>=1 && v_result<=9) {
				//Ask for advance runner input
				if(ballgame.isRunnersOnBase() && v_result>=1 && v_result<=3) {
					if (v_result>=1 && v_result<=3) {
				
						//Show runner menu
						for(int i=3;i>0;i--) {
							ballgame.getBaseSituations(v_result, i);
							base_situation="";
							base_situation=ballgame.getCurrent_base_situation();
							
							if(!ballgame.isBasesEmpty() && base_situation.length()>3) {
								mav.addObject("Base", i);
								mav.addObject("MoveRunner",1);
								mav.addObject("Runner_situation",base_situation);
								mav.addObject("current_result", ballgame.getCurrent_result());
								session.setAttribute("current_base", i);
								session.setAttribute("current_input", v_result);
								break;
							}
						}
						
						if(ballgame.isBasesEmpty() && base_situation.length()<3) {
							ballgame.recordTransaction(v_result);
							ballgame.updateTransaction();
							mav.addObject("current_plays", ballgame.getGamelog_Current());
							mav.addObject("current_result", ballgame.getCurrent_result());
							mav.addObject("MoveRunner",0);
						}
						
						
					
					}
				}
					
//					
//					for(int i=3;i>=0;i--) {
//						if(OnBase.get(i)!=null && OnBase.get(i-1)!=null && OnBase.get(i-2)!=null && i==3) {
//							Hitter runner=OnBase.get(i);
//							ballgame.setBaseSituation(i, current_hitter);
//							//System.out.print(runner.getFullName() + " is on " + i + ". ");
//						}
//					}
					
					
					
//					if(RunnersOnBase) {
//						//setBaseSituations(scanner);
//					}
//					
//					
//					if(RunnersOnBase) {
//						//setBaseSituations(scanner);
//					}
//					
//					//If player walks, put him on base
//					//OnBase.put(1, current_Hitter);
//					//setBaseSituation(1, current_Hitter);
//					//If player walks, put him on base
//					OnBase.put(1, current_hitter);
//					ballgame.setBaseSituation(1, current_hitter);
//					
//					ballgame.recordTransaction(v_result);
//					ballgame.updateTransaction();
//					mav.addObject("current_result", ballgame.getCurrent_result());
//					mav.addObject("MoveRunner",0);
//					
//					Hitter runner=ballgame.getCurrent_Hitter();
//					bal
//					
//					
//					ballgame.advanceRunner(frombase, tobase);
					
					
				else{
					//Show regular menu

					ballgame.recordTransaction(v_result);
					ballgame.updateTransaction();
					mav.addObject("current_plays", ballgame.getGamelog_Current());
					mav.addObject("current_result", ballgame.getCurrent_result());
					mav.addObject("MoveRunner",0);
					
				}
			}
				
			

			
			if(ballgame.checkifGameOver()) {
				mav=new ModelAndView("results");
				
				ballgame.getScoringSummary();
				
				List<GameLog> gameLogs=ballgame.getGamelog_Scoring();
				
				mav.addObject("visit_team_hitters", ballgame.getVisit_Hitters());
				mav.addObject("home_team_hitters", ballgame.getHome_Hitters());	
				mav.addObject("visit_team", ballgame.getVisit_team());
				mav.addObject("home_team", ballgame.getHome_team());
				mav.addObject("visit_runs", ballgame.getTotal_visitteam_runs());
				mav.addObject("home_runs", ballgame.getTotal_hometeam_runs());
				mav.addObject("scoring_summary", gameLogs);		
				
				System.out.println("Game is over");
				
				return mav;
				//pResponse.sendRedirect("result");

			}
				
			
			ballgame.getGameMenu();			
			
																		
			for(int i=1;i<=OnBase.size();i++) {
				if(OnBase.get(i)!=null) {
					Hitter runner=OnBase.get(i);
					mav.addObject("Runner_" + i, runner.getFullName());
					//System.out.print(runner.getFullName() + " is on " + i + ". ");
				}
			}
			

			
			mav.addObject("visit_team", ballgame.getVisit_team());
			mav.addObject("home_team", ballgame.getHome_team());
									
			mav.addObject("current_hitter", ballgame.getCurrent_Hitter());
			mav.addObject("current_pitcher", ballgame.getCurrent_Pitcher());
			mav.addObject("balls", ballgame.getBalls());
			mav.addObject("strikes", ballgame.getStrikes());
			mav.addObject("outs", ballgame.getOuts());
			mav.addObject("inning", ballgame.getInning());
			mav.addObject("top", (ballgame.isTop())?"Top":"Bottom");	
			mav.addObject("visit_runs", ballgame.getTotal_visitteam_runs());
			mav.addObject("home_runs", ballgame.getTotal_hometeam_runs());
			
			
			//Set Session Attribute
			session.setAttribute("v_result", v_result);
			session.setAttribute("ballgame", ballgame);
			
				
			return mav;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Error: " + e.getMessage());
		}
		return null;
	}
	
	/**
	 * Handler to gather user input to advance runner.
	 *
	 * @param user the user
	 * @param pRequest the request
	 * @param pResponse the response
	 * @param move_to the move to
	 * @param baseId the base id
	 * @return the model and view
	 */
	
	
	@RequestMapping(value= {"/move_runner"},method=RequestMethod.POST)
	public ModelAndView movePost(@ModelAttribute("user") User user,HttpServletRequest pRequest, HttpServletResponse pResponse,
			@RequestParam("inputId") String move_to, @RequestParam("baseId") String baseId) {
		
		try {

			
			HttpSession session=pRequest.getSession();
			ModelAndView mav=new ModelAndView("tracker");
			
			
			Game ballgame=(Game) session.getAttribute("ballgame");
			int current_input=(int) session.getAttribute("current_input");
			int v_result=(int) session.getAttribute("v_result");
			
			//int base_count=(int) session.getAttribute("bases");
			//Map<Integer, Hitter> OnBase=ballgame.getOnBase();
			//OnBase.get(base_count);
			
			
			int v_move=Integer.parseInt(move_to);
			int v_base=Integer.parseInt(baseId);		
			
			
			//String move_result="Player 1 moved from " + baseId + " to " + move_to;

			ballgame.advanceRunner(v_base, v_move);

			//Look for next base
			v_base--;
			
			//mav.addObject("Result", move_result);
			mav.addObject("Base", v_base);
			
			
			
			//If bases are clear from input
			if(v_base==0) {

				ballgame.recordTransaction(current_input);
				ballgame.updateTransaction();
				mav.addObject("current_result", ballgame.getCurrent_result());
				mav.addObject("MoveRunner",0);
				
				ballgame.getGameMenu();			
				
				Hitter current_hitter=ballgame.getCurrent_Hitter();
				Pitcher current_pitcher=ballgame.getCurrent_Pitcher();
				
				mav.addObject("current_hitter", current_hitter);
				mav.addObject("current_pitcher", current_pitcher);
				
				if(ballgame.checkifGameOver()) {
					mav=new ModelAndView("results");
					
					ballgame.getScoringSummary();
					
					List<GameLog> gameLogs=ballgame.getGamelog_Scoring();
					
					
					mav.addObject("visit_team_hitters", ballgame.getVisit_Hitters());
					mav.addObject("home_team_hitters", ballgame.getHome_Hitters());	
					mav.addObject("visit_team", ballgame.getVisit_team());
					mav.addObject("home_team", ballgame.getHome_team());
					mav.addObject("visit_runs", ballgame.getTotal_visitteam_runs());
					mav.addObject("home_runs", ballgame.getTotal_hometeam_runs());
					mav.addObject("scoring_summary", gameLogs);		
					
					System.out.println("Game is over");
					
					return mav;
				}
					
					
			}else {
				for(int i=v_base;i>0;i--) {
					ballgame.getBaseSituations(current_input, i);
					base_situation="";
					base_situation=ballgame.getCurrent_base_situation();
					
					if(base_situation.length()>3) {
						mav.addObject("Base", i);
						mav.addObject("MoveRunner",1);
						mav.addObject("Runner_situation",base_situation);
						session.setAttribute("current_base", i);
						session.setAttribute("current_input", current_input);
						break;
					}
				}
			}
		
			
			if(ballgame.getCurrent_base_situation().length()<3) {
				ballgame.recordTransaction(v_result);
				ballgame.updateTransaction();
				mav.addObject("current_plays", ballgame.getGamelog_Current());
				mav.addObject("current_result", ballgame.getCurrent_result());
				mav.addObject("MoveRunner",0);
			}
			
			
			ballgame.getGameMenu();			
			
			Hitter current_hitter=ballgame.getCurrent_Hitter();
			Pitcher current_pitcher=ballgame.getCurrent_Pitcher();
			
			
			Map<Integer, Hitter> OnBase=ballgame.getOnBase();
			
			//Assign Runners
			for(int i=1;i<=OnBase.size();i++) {
				if(OnBase.get(i)!=null) {
					Hitter runner=OnBase.get(i);
					mav.addObject("Runner_" + i, runner.getFullName());
					//System.out.print(runner.getFullName() + " is on " + i + ". ");
				}
			}
			
			mav.addObject("current_hitter", current_hitter);
			mav.addObject("current_pitcher", current_pitcher);
			mav.addObject("balls", ballgame.getBalls());
			mav.addObject("strikes", ballgame.getStrikes());
			mav.addObject("outs", ballgame.getOuts());
			mav.addObject("inning", ballgame.getInning());
			mav.addObject("top", (ballgame.isTop())?"Top":"Bottom");	
			mav.addObject("visit_runs", ballgame.getTotal_visitteam_runs());
			mav.addObject("home_runs", ballgame.getTotal_hometeam_runs());
			
			
			mav.addObject("visit_team", ballgame.getVisit_team());
			mav.addObject("home_team", ballgame.getHome_team());
			
			//Set Session Attribute
			session.setAttribute("ballgame", ballgame);
			
			return mav;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Error: " + e.getMessage());
		}
		return null;
	}
	
	
	/**
	 * Final page to render results.
	 *
	 * @param user the user
	 * @param pRequest the request
	 * @return the model and view
	 */
	
	
	//<a  class="menuheaderscore" href="player_results">Player ScoreCard</a> | <a class="menuheaderscore" href="score_summary">Scoring Summary</a>
	
	@RequestMapping("/player_results")
	public ModelAndView rplayer_resultsPage(@ModelAttribute("user") User user,HttpServletRequest pRequest) {
		
		
		System.out.println("RESULTS PAGE IS HERE");
		
		HttpSession session=pRequest.getSession();
		
		Game ballgame=(Game) session.getAttribute("ballgame");
		
		ballgame.getScoringSummary();
				
		List<GameLog> gameLogs=ballgame.getGamelog_Scoring();

		ModelAndView mav=new ModelAndView("results");
		
		mav.addObject("visit_team_hitters", ballgame.getVisit_Hitters());
		mav.addObject("home_team_hitters", ballgame.getHome_Hitters());	
		mav.addObject("visit_team", ballgame.getVisit_team());
		mav.addObject("home_team", ballgame.getHome_team());
		mav.addObject("visit_runs", ballgame.getTotal_visitteam_runs());
		mav.addObject("home_runs", ballgame.getTotal_hometeam_runs());
		mav.addObject("scoring_summary", gameLogs);		
		
//		System.out.println("Size of list: " + gameLogs.size());
//		
//		for (GameLog gameLog : gameLogs) {
//			System.out.println(gameLog.getResult());
//		}
		
		//Set Session Attribute
		session.setAttribute("ballgame", ballgame);
		
		System.out.println("RESULTS PAGE HAS ENDED");
		
		return mav;
		
	}
	
	
	/**
	 * Score summary page.
	 *
	 * @param pRequest the request
	 * @return the model and view
	 */
	@RequestMapping("/score_summary")
	public ModelAndView score_summaryPage(HttpServletRequest pRequest) {
		
		
		System.out.println("SCORE SUMMARY PAGE IS HERE");
		
		HttpSession session=pRequest.getSession();
		
		Game ballgame=(Game) session.getAttribute("ballgame");
		
		ballgame.getScoringSummary();
				
		List<GameLog> gameLogs=ballgame.getGamelog_Scoring();

		ModelAndView mav=new ModelAndView("score_summary");
		
		mav.addObject("visit_team_hitters", ballgame.getVisit_Hitters());
		mav.addObject("home_team_hitters", ballgame.getHome_Hitters());	
		mav.addObject("visit_team", ballgame.getVisit_team());
		mav.addObject("home_team", ballgame.getHome_team());
		mav.addObject("visit_runs", ballgame.getTotal_visitteam_runs());
		mav.addObject("home_runs", ballgame.getTotal_hometeam_runs());
		mav.addObject("scoring_summary", gameLogs);		
		
		//Set Session Attribute
		session.setAttribute("ballgame", ballgame);
		
		System.out.println("SCORE SUMMARY PAGE HAS ENDED");
		
		return mav;
		
	}
	
	
	
	/**
	 * Team standings page.
	 *
	 * @param pRequest the request
	 * @return the model and view
	 */
	@RequestMapping("/team_standings")
	public ModelAndView team_standingsPage(HttpServletRequest pRequest) {
		
		
		System.out.println("Team Standings PAGE IS HERE");
		
		HttpSession session=pRequest.getSession();
		
		Game ballgame=(Game) session.getAttribute("ballgame");
		
		ballgame.getScoringSummary();
				
		//List<Team> gameLogs=ballgame.getGamelog_Scoring();

		ModelAndView mav=new ModelAndView("team_standings");
		
		mav.addObject("visit_team_hitters", ballgame.getVisit_Hitters());
		mav.addObject("home_team_hitters", ballgame.getHome_Hitters());	
		mav.addObject("visit_team", ballgame.getVisit_team());
		mav.addObject("home_team", ballgame.getHome_team());
		mav.addObject("visit_runs", ballgame.getTotal_visitteam_runs());
		mav.addObject("home_runs", ballgame.getTotal_hometeam_runs());
		mav.addObject("team_standings", ballgame.getAll_teams_standings());		
		
		//Set Session Attribute
		session.setAttribute("ballgame", ballgame);
		
		System.out.println("Team Standings PAGE HAS ENDED");
		
		return mav;
		
	}
	
	
	/**
	 * Player profile.
	 *
	 * @param pRequest the request
	 * @param player_id the player id
	 * @return the model and view
	 */
	@RequestMapping("/player_profile")
	public ModelAndView player_profile(HttpServletRequest pRequest, @RequestParam("player_id") String player_id) {
		
		
		System.out.println("Player_Profile PAGE IS HERE");

		int v_player_id=Integer.parseInt(player_id);
		
		HttpSession session=pRequest.getSession();
		
		Game ballgame=(Game) session.getAttribute("ballgame");
		
		//ballgame.getScoringSummary();
				
		//List<Team> gameLogs=ballgame.getGamelog_Scoring();

		ModelAndView mav=new ModelAndView("player_profile");
		
		mav.addObject("profile", ballgame.getHitterProfile(v_player_id));
		mav.addObject("visit_team_hitters", ballgame.getVisit_Hitters());
		mav.addObject("home_team_hitters", ballgame.getHome_Hitters());	
		mav.addObject("visit_team", ballgame.getVisit_team());
		mav.addObject("home_team", ballgame.getHome_team());
		mav.addObject("visit_runs", ballgame.getTotal_visitteam_runs());
		mav.addObject("home_runs", ballgame.getTotal_hometeam_runs());
		mav.addObject("team_standings", ballgame.getAll_teams_standings());
		mav.addObject("player_gamelog", ballgame.getHitterGameLog(v_player_id));		
		
		//Set Session Attribute
		session.setAttribute("ballgame", ballgame);
		
		System.out.println("Player_Profile PAGE HAS ENDED");
		
		return mav;
		
	}
}
