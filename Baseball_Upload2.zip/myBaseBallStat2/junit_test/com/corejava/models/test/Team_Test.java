package com.corejava.models.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import CoreJava.Models.Team;

// TODO: Auto-generated Javadoc
/**
 * The Class Team_Test.
 */
public class Team_Test {
	
	/** The team expected. */
	Team team_expected;	
	/** The team actual. */
	Team team_actual;

	/**
	 * Sets the up before class.
	 *
	 * @throws Exception the exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("@BeforeClass - TEAM MODEL");
	}

	/**
	 * Tear down after class.
	 *
	 * @throws Exception the exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("@AfterClass - TEAM MODEL");
	}

	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {

		team_expected=new Team(3,"Reds","Cincinnati","Black","Red River",61,83);
		team_actual=new Team();
		
		System.out.println("@Before TestSetters INTIZALIZE OBJECTS && TEST SETTERS");
		
		team_actual.setTeam_id(3);
		team_actual.setTeam_name("Reds");
		team_actual.setCity("Cincinnati");
		team_actual.setColor("Black");
		team_actual.setStadium("Red River");
		team_actual.setWins(61);
		team_actual.setLosses(83);		
	}

	/**
	 * Tear down.
	 *
	 * @throws Exception the exception
	 */
	@After
	public void tearDown() throws Exception {
		System.out.println("@After FINISH METHOD");
	}

	/**
	 * Test get full name.
	 */
	@Test
	public final void testGetFullName() {
		System.out.println("@Test TestGetters TEST GETTERS");

		assertTrue(team_expected.getTeam_id()==team_actual.getTeam_id());
		assertTrue(team_expected.getTeam_name().equals(team_actual.getTeam_name()));
		assertTrue(team_expected.getCity()==team_actual.getCity());
		assertTrue(team_expected.getColor()==team_actual.getColor());
		assertTrue(team_expected.getStadium()==team_actual.getStadium());
		assertTrue(team_expected.getWins()==team_actual.getWins());
		assertTrue(team_expected.getLosses()==team_actual.getLosses());
	}

	/**
	 * Test set full name.
	 */
	@Test
	public final void testSetFullName() {
		System.out.println("@Test EqualsObjects TEST OBJECTS ARE EQUAL");
		
		assertEquals(team_expected, team_actual);
	}

}

